import { supabaseServiceRoleKey, supabaseUrl } from "@/lib/supabase";

export async function POST(request: Request) {
  if (!supabaseUrl || !supabaseServiceRoleKey) {
    return Response.json({ message: "Supabase env missing" }, { status: 500 });
  }

  const { fullName, companyName, email, password, phone } = await request.json();

  const response = await fetch(`${supabaseUrl}/auth/v1/admin/users`, {
    method: "POST",
    headers: {
      apikey: supabaseServiceRoleKey,
      Authorization: `Bearer ${supabaseServiceRoleKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      email,
      password,
      email_confirm: true,
      user_metadata: {
        full_name: fullName,
        company_name: companyName,
        phone,
      },
    }),
  });

  const data = await response.json();

  if (!response.ok) {
    const errorMessage =
      data.msg || data.message || data.error_description || "Sign up failed";
    const normalizedMessage = errorMessage.toLowerCase();

    return Response.json(
      {
        message:
          normalizedMessage.includes("already") ||
          normalizedMessage.includes("registered") ||
          normalizedMessage.includes("exists")
            ? "Account already exists. Please login."
            : errorMessage,
      },
      { status: response.status }
    );
  }

  return Response.json({ ok: true });
}
