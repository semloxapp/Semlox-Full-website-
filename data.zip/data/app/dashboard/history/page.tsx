"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  Activity,
  Bell,
  FileText,
  Filter,
  Home,
  LogOut,
  Settings,
  Upload,
} from "lucide-react";

function Sidebar() {
  return (
    <aside className="flex h-full min-h-0 w-[220px] shrink-0 flex-col border-r border-white/[0.06] bg-[#070B17] px-2 py-3 text-white">
      <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
        Menu
      </div>

      <nav className="space-y-1">
        <Link
          href="/dashboard"
          className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]"
        >
          <Home className="h-3.5 w-3.5" />
          Overview
        </Link>

        <Link href="/dashboard/awb" className="flex h-[30px] items-center justify-between rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <span className="flex items-center gap-2">
            <FileText className="h-3.5 w-3.5" />
            AWB Processing
          </span>
          <span className="flex h-[15px] w-[15px] items-center justify-center rounded-full bg-[#123D8A] text-[8px] font-bold text-[#4F8BFF]">
            3
          </span>
        </Link>

        <Link
          href="/dashboard/history"
          className="flex h-[30px] items-center gap-2 rounded-[6px] border border-[#1B3B73] bg-[#0D1B35] px-3 text-[11px] font-bold text-white shadow-[inset_3px_0_0_#2F80FF]"
        >
          <Activity className="h-3.5 w-3.5" />
          History
        </Link>

        <Link href="/dashboard/settings" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <Settings className="h-3.5 w-3.5" />
          Settings
        </Link>
      </nav>

      <div className="mt-3 border-t border-white/[0.06] pt-2">
        <div className="rounded-[7px] border border-[#17325F] bg-[#0A1530] p-3">
          <h3 className="text-[10px] font-bold text-white">Enterprise Plan</h3>
          <p className="mt-1 text-[8px] text-[#7D8EA8]">10,000 AWBs/month</p>
          <div className="mt-2 h-[3px] w-full rounded-full bg-[#132746]">
            <div className="h-full w-[48%] rounded-full bg-[#00D9FF]" />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-[8px]">
            <span className="text-[#2F80FF]">4,823</span>
            <span className="text-[#64748B]">of 10,000 used</span>
          </div>
        </div>
      </div>

      <div className="mt-4 border-t border-white/[0.06] pt-3">
        <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
          Support
        </div>
        <a className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <FileText className="h-3.5 w-3.5" />
          Documentation
        </a>
      </div>

      <div className="mt-auto border-t border-white/[0.06] pt-3">
        <Link href="/logout" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <LogOut className="h-3.5 w-3.5" />
          Logout
        </Link>
      </div>
    </aside>
  );
}

function AppHeader() {
  return (
    <div className="fixed left-0 right-0 top-0 z-[200] flex h-[42px] items-center justify-between border-b border-white/[0.08] bg-[#070B17] px-5 text-white">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-md bg-[#2F80FF]">
            <span className="text-[11px] font-bold text-white">S</span>
          </div>
          <div className="leading-none">
            <h1 className="text-[12px] font-bold">SemloX</h1>
            <p className="mt-1 text-[8px] tracking-[0.1em] text-[#64748B]">
              AI DOCUMENT ENGINE
            </p>
          </div>
        </div>

        <div className="ml-12 h-10 w-px bg-white/[0.09]" />

        <div className="ml-3 leading-none">
          <h2 className="mb-0.5 text-[11px] font-semibold text-white">History</h2>
          <p className="text-[8px] text-[#64748B]">
            DB Schenker Logistics · Thu, 24 Apr 2026
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button className="flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#2F80FF] to-[#00C6FF] px-3 py-[5px] text-[10px] font-semibold text-white shadow-md hover:opacity-90">
          <Upload className="h-3 w-3" />
          Upload AWB
        </button>
        <button className="flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
          <Filter className="h-3.5 w-3.5 text-[#64748B]" />
        </button>
        <button className="relative flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
          <Bell className="h-3.5 w-3.5 text-[#64748B]" />
          <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-red-500" />
        </button>
        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#5865F2] text-[10px] font-bold">
          AK
        </div>
      </div>
    </div>
  );
}

void Sidebar;
void AppHeader;

// function Topbar() {
//   return (
//     <header className="flex h-14 shrink-0 items-center gap-4 border-b border-[#E5E7EB] bg-white px-6">
//       <div>
//         <div className="text-base font-bold tracking-[-0.02em] text-[#111827]">
//           Command Center
//         </div>
//         <div className="mt-px text-[11px] text-[#6B7280]">
//           History Overview · Today, 24 Apr 2026
//         </div>
//       </div>
//     </header>
//   );
// }



type Theme = "dark" | "light";
type DocStatus = "ok" | "pdf" | "issued" | "draft" | "partial" | "fail";
type DateQuick = "all" | "today" | "7d" | "30d";
type StatusFilter = DocStatus | "all";
type SortColumn = keyof Pick<DocRow, "date" | "awb" | "action" | "type" | "fields" | "user" | "status">;

type DocRow = {
  id: number;
  date: string;
  time: string;
  awb: string;
  action: string;
  type: string;
  status: DocStatus;
  fields: number;
  extracted: number;
  user: string;
  size: string;
  pages: number;
};

const iconPaths = {
  home: "M2 6L8 1l6 5v8a1 1 0 01-1 1H3a1 1 0 01-1-1V6zM6 15V9h4v6",
  doc: "M9 1H3a1 1 0 00-1 1v12a1 1 0 001 1h10a1 1 0 001-1V5L9 1zM9 1v4h4M5 9h6M5 12h4",
  history: "M8 1a7 7 0 100 14A7 7 0 008 1zM8 4v4l2.5 1.5",
  gear: "M8 5.5A2.5 2.5 0 118 10.5A2.5 2.5 0 018 5.5zM8 1v2M8 13v2M1 8h2M13 8h2",
  bell: "M8 1a4 4 0 014 4v4l1.5 2H.5L2 9V5a4 4 0 014-4zM6.5 13a1.5 1.5 0 003 0",
  search: "M7 12A5 5 0 107 2a5 5 0 000 10zM14 14l-3-3",
  upload: "M8 2v9M5 5l3-3 3 3M2 13h12",
  refresh: "M13 8a5 5 0 11-1.4-3.5M14 2v4h-4",
  x: "M3 3l10 10M13 3L3 13",
  open: "M10 3h4v4M14 3L9 8M7 3H3a1 1 0 00-1 1v9a1 1 0 001 1h9a1 1 0 001-1V9",
  dl: "M8 2v9M5 11l3 3 3-3M2 15h12",
  more: "M4 8h.01M8 8h.01M12 8h.01",
  cal: "M1 5h14M3 1v3M13 1v3M1 3h14v11a1 1 0 01-1 1H2a1 1 0 01-1-1V3z",
  sun: "M8 11A3 3 0 108 5a3 3 0 000 6zM8 1v2M8 13v2M1 8h2M13 8h2M3 3l1.4 1.4M11.6 11.6L13 13M3 13l1.4-1.4M11.6 4.4L13 3",
  moon: "M9 2a7 7 0 00-7 7 7 7 0 007 7 7 0 004.9-2.1A5 5 0 019 2z",
  check: "M2 8l4 4 8-6",
  col: "M2 2h4v12H2zM10 2h4v12h-4z",
  chevR: "M6 3l5 5-5 5",
} as const;

function Icon({ name, size = 15, className = "" }: { name: keyof typeof iconPaths; size?: number; className?: string }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 16 16"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.6"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d={iconPaths[name]} />
    </svg>
  );
}

const docs: DocRow[] = [
  { id: 1, date: "27/04/2026", time: "10:42:15 am", awb: "724-12849302", action: "Initial Extraction", type: "AWB", status: "ok", fields: 14, extracted: 14, user: "Anna K.", size: "248 KB", pages: 2 },
  { id: 2, date: "27/04/2026", time: "10:41:52 am", awb: "724-12849302", action: "Generated PDF", type: "AWB", status: "pdf", fields: 14, extracted: 14, user: "Anna K.", size: "312 KB", pages: 2 },
  { id: 3, date: "27/04/2026", time: "10:41:55 am", awb: "724-12849302", action: "Issued AWB", type: "AWB", status: "issued", fields: 14, extracted: 14, user: "Anna K.", size: "312 KB", pages: 2 },
  { id: 4, date: "27/04/2026", time: "09:18:03 am", awb: "180-00293817", action: "Initial Extraction", type: "AWB", status: "partial", fields: 14, extracted: 11, user: "M. Schulz", size: "184 KB", pages: 1 },
  { id: 5, date: "27/04/2026", time: "09:18:40 am", awb: "180-00293817", action: "Draft Saved", type: "AWB", status: "draft", fields: 14, extracted: 11, user: "M. Schulz", size: "184 KB", pages: 1 },
  { id: 6, date: "26/04/2026", time: "04:55:22 pm", awb: "618-44192003", action: "Initial Extraction", type: "AWB", status: "fail", fields: 14, extracted: 0, user: "T. Bauer", size: "512 KB", pages: 3 },
  { id: 7, date: "26/04/2026", time: "02:30:10 pm", awb: "020-91843001", action: "Initial Extraction", type: "AWB", status: "ok", fields: 14, extracted: 14, user: "Anna K.", size: "196 KB", pages: 1 },
  { id: 8, date: "26/04/2026", time: "02:30:55 pm", awb: "020-91843001", action: "Generated PDF", type: "AWB", status: "pdf", fields: 14, extracted: 14, user: "Anna K.", size: "206 KB", pages: 1 },
  { id: 9, date: "26/04/2026", time: "02:31:12 pm", awb: "020-91843001", action: "Issued AWB", type: "AWB", status: "issued", fields: 14, extracted: 14, user: "Anna K.", size: "206 KB", pages: 1 },
  { id: 10, date: "25/04/2026", time: "11:12:34 am", awb: "083-22019847", action: "Initial Extraction", type: "AWB", status: "partial", fields: 14, extracted: 13, user: "K. Weber", size: "302 KB", pages: 2 },
  { id: 11, date: "25/04/2026", time: "11:13:01 am", awb: "083-22019847", action: "Generated PDF", type: "AWB", status: "pdf", fields: 14, extracted: 13, user: "K. Weber", size: "318 KB", pages: 2 },
  { id: 12, date: "24/04/2026", time: "03:45:00 pm", awb: "083-11234567", action: "Initial Extraction", type: "AWB", status: "ok", fields: 14, extracted: 14, user: "M. Schulz", size: "178 KB", pages: 1 },
  { id: 13, date: "24/04/2026", time: "03:45:30 pm", awb: "083-11234567", action: "Generated PDF", type: "AWB", status: "pdf", fields: 14, extracted: 14, user: "M. Schulz", size: "192 KB", pages: 1 },
  { id: 14, date: "24/04/2026", time: "03:46:00 pm", awb: "083-11234567", action: "Issued AWB", type: "AWB", status: "issued", fields: 14, extracted: 14, user: "M. Schulz", size: "192 KB", pages: 1 },
  { id: 15, date: "23/04/2026", time: "09:00:00 am", awb: "999-00112233", action: "Initial Extraction", type: "AWB", status: "fail", fields: 14, extracted: 0, user: "T. Bauer", size: "88 KB", pages: 1 },
  { id: 16, date: "22/04/2026", time: "02:14:55 pm", awb: "447-83920011", action: "Initial Extraction", type: "AWB", status: "ok", fields: 14, extracted: 14, user: "Anna K.", size: "224 KB", pages: 2 },
  { id: 17, date: "22/04/2026", time: "02:15:30 pm", awb: "447-83920011", action: "Issued AWB", type: "AWB", status: "issued", fields: 14, extracted: 14, user: "Anna K.", size: "224 KB", pages: 2 },
  { id: 18, date: "21/04/2026", time: "10:05:10 am", awb: "339-00488271", action: "Initial Extraction", type: "AWB", status: "partial", fields: 14, extracted: 12, user: "K. Weber", size: "155 KB", pages: 1 },
];

const statusConfig: Record<DocStatus, { label: string; className: string; colorClass: string }> = {
  ok: { label: "Success", className: "border-emerald-500/20 bg-emerald-500/10 text-emerald-400", colorClass: "bg-emerald-400" },
  pdf: { label: "PDF Generated", className: "border-violet-500/20 bg-violet-500/10 text-violet-400", colorClass: "bg-violet-400" },
  issued: { label: "AWB Issued", className: "border-blue-500/20 bg-blue-500/10 text-blue-400", colorClass: "bg-blue-400" },
  draft: { label: "Draft Saved", className: "border-amber-500/20 bg-amber-500/10 text-amber-400", colorClass: "bg-amber-400" },
  partial: { label: "Partial", className: "border-orange-500/20 bg-orange-500/10 text-orange-400", colorClass: "bg-orange-400" },
  fail: { label: "Failed", className: "border-red-500/20 bg-red-500/10 text-red-400", colorClass: "bg-red-400" },
};

const actionColor: Record<string, string> = {
  "Initial Extraction": "text-cyan-400",
  "Generated PDF": "text-violet-400",
  "Issued AWB": "text-blue-400",
  "Draft Saved": "text-amber-400",
};

const tableColumns: { key: SortColumn; label: string }[] = [
  { key: "date", label: "Date" },
  { key: "awb", label: "AWB Number" },
  { key: "action", label: "Action" },
  { key: "type", label: "Type" },
  { key: "fields", label: "Fields" },
  { key: "user", label: "Processed By" },
  { key: "status", label: "Status" },
];

const months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
const days = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

function formatDate(date: Date | null) {
  if (!date) return null;
  return `${String(date.getDate()).padStart(2, "0")}/${String(date.getMonth() + 1).padStart(2, "0")}/${date.getFullYear()}`;
}

function Calendar({ value, onChange, onClose }: { value: Date | null; onChange: (date: Date | null) => void; onClose: () => void }) {
  const today = new Date(2026, 3, 27);
  const [current, setCurrent] = useState({ month: value ? value.getMonth() : today.getMonth(), year: value ? value.getFullYear() : today.getFullYear() });

  const firstDay = new Date(current.year, current.month, 1);
  const startOffset = firstDay.getDay();
  const daysInMonth = new Date(current.year, current.month + 1, 0).getDate();
  const daysInPreviousMonth = new Date(current.year, current.month, 0).getDate();

  const cells: { day: number; currentMonth: boolean }[] = [];
  for (let i = 0; i < startOffset; i += 1) cells.push({ day: daysInPreviousMonth - startOffset + i + 1, currentMonth: false });
  for (let i = 1; i <= daysInMonth; i += 1) cells.push({ day: i, currentMonth: true });
  while (cells.length % 7 !== 0) cells.push({ day: cells.length - daysInMonth - startOffset + 1, currentMonth: false });

  return (
    <div className="absolute left-0 top-[calc(100%+8px)] z-50 min-w-[300px] animate-[fadeUp_0.15s_ease] rounded-[14px] border border-white/10 bg-[#0d1323] p-4 shadow-[0_20px_60px_rgba(0,0,0,0.5)] dark:bg-[#0d1323]" onClick={(event) => event.stopPropagation()}>
      <div className="mb-3.5 flex items-center justify-between">
        <div className="flex gap-1">
          <button className="flex h-7 w-7 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-500 transition hover:border-blue-500/30 hover:text-blue-400" onClick={() => setCurrent((c) => (c.month === 0 ? { month: 11, year: c.year - 1 } : { month: c.month - 1, year: c.year }))}>‹</button>
          <button className="flex h-7 w-7 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-500 transition hover:border-blue-500/30 hover:text-blue-400" onClick={() => setCurrent((c) => (c.month === 11 ? { month: 0, year: c.year + 1 } : { month: c.month + 1, year: c.year }))}>›</button>
        </div>
        <div className="text-[13px] font-bold text-slate-100">{months[current.month]} {current.year}</div>
      </div>

      <div className="grid grid-cols-7 gap-0.5">
        {days.map((day) => <div key={day} className="py-1 text-center font-mono text-[10px] tracking-wider text-slate-500">{day}</div>)}
        {cells.map((cell, index) => {
          const isToday = cell.currentMonth && cell.day === today.getDate() && current.month === today.getMonth() && current.year === today.getFullYear();
          const isSelected = value && cell.currentMonth && cell.day === value.getDate() && current.month === value.getMonth() && current.year === value.getFullYear();
          return (
            <button
              key={`${cell.day}-${index}`}
              className={`flex h-9 w-9 items-center justify-center rounded-lg border border-transparent text-xs transition ${cell.currentMonth ? "text-slate-300 hover:bg-blue-500/10 hover:text-blue-400" : "text-slate-500/40"} ${isToday ? "border-blue-500/30 font-bold text-blue-400" : ""} ${isSelected ? "bg-blue-500 font-bold text-white hover:bg-blue-500 hover:text-white" : ""}`}
              onClick={() => cell.currentMonth && onChange(new Date(current.year, current.month, cell.day))}
            >
              {cell.day}
            </button>
          );
        })}
      </div>

      <div className="mt-3.5 flex gap-2 border-t border-white/10 pt-3.5">
        <button className="flex-1 rounded-lg border border-white/10 bg-transparent p-2 text-xs font-semibold text-slate-500 transition hover:text-slate-200" onClick={() => onChange(null)}>Clear</button>
        <button className="flex-1 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 p-2 text-xs font-semibold text-white" onClick={onClose}>Apply</button>
      </div>
    </div>
  );
}

function DateRangePicker({ from, to, onChange }: { from: Date | null; to: Date | null; onChange: (from: Date | null, to: Date | null) => void }) {
  const [open, setOpen] = useState<"from" | "to" | null>(null);
  const pickerRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const handleClick = (event: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(event.target as Node)) setOpen(null);
    };
    document.addEventListener("mousedown", handleClick);
    return () => document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div ref={pickerRef} className="relative flex items-center gap-1.5">
      <button className={`flex items-center gap-2 rounded-lg border px-3 py-[7px] text-xs transition ${from ? "border-blue-500/30 text-blue-400" : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-blue-500/30"}`} onClick={() => setOpen(open === "from" ? null : "from")}>
        <Icon name="cal" size={12} />
        {formatDate(from) ?? "From date"}
      </button>
      <span className="text-[11px] text-slate-500">→</span>
      <button className={`flex items-center gap-2 rounded-lg border px-3 py-[7px] text-xs transition ${to ? "border-blue-500/30 text-blue-400" : "border-white/10 bg-white/[0.04] text-slate-300 hover:border-blue-500/30"}`} onClick={() => setOpen(open === "to" ? null : "to")}>
        <Icon name="cal" size={12} />
        {formatDate(to) ?? "To date"}
      </button>
      {open === "from" && <Calendar value={from} onChange={(date) => { onChange(date, to); if (date) setOpen("to"); }} onClose={() => setOpen(null)} />}
      {open === "to" && <Calendar value={to} onChange={(date) => { onChange(from, date); setOpen(null); }} onClose={() => setOpen(null)} />}
    </div>
  );
}

function Badge({ status }: { status: DocStatus }) {
  const config = statusConfig[status];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-[10px] font-semibold tracking-wide ${config.className}`}>
      <span className="h-1 w-1 rounded-full bg-current" />
      {config.label}
    </span>
  );
}

function CheckboxBox({ checked, onClick }: { checked: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex h-[15px] w-[15px] shrink-0 items-center justify-center rounded border-[1.5px] transition ${checked ? "border-blue-500 bg-blue-500 text-white" : "border-white/10 bg-white/[0.04]"}`}>
      {checked && <Icon name="check" size={9} />}
    </button>
  );
}

function DetailPanel({ doc, onClose }: { doc: DocRow | null; onClose: () => void }) {
  if (!doc) return null;

  const fieldColor = (value: number) => {
    if (value >= 95) return "bg-emerald-400 text-emerald-400";
    if (value >= 85) return "bg-amber-400 text-amber-400";
    if (value > 0) return "bg-orange-400 text-orange-400";
    return "bg-red-400 text-red-400";
  };

  const fields = [
    { label: "AWB Number", value: doc.awb, confidence: 99 },
    { label: "Shipper Name", value: "DB Schenker GmbH", confidence: 99 },
    { label: "Consignee", value: "Siemens AG — SIN", confidence: 98 },
    { label: "Origin Airport", value: "FRA — Frankfurt", confidence: 99 },
    { label: "Dest. Airport", value: "SIN — Singapore", confidence: 99 },
    { label: "Gross Weight", value: "1,240 kg", confidence: 98 },
    { label: "Pieces", value: "14 pcs", confidence: 97 },
    { label: "HS Code", value: doc.extracted >= 13 ? "8471.30.0000" : "Not extracted", confidence: doc.extracted >= 13 ? 94 : 0 },
    { label: "Flight No.", value: doc.extracted >= 13 ? "LH9012" : "Not extracted", confidence: doc.extracted >= 13 ? 91 : 0 },
    { label: "Special Handling", value: doc.extracted >= 12 ? "CAO" : "Not extracted", confidence: doc.extracted >= 12 ? 87 : 0 },
  ];

  const timeline = [
    { label: "File Uploaded", time: "10:41:50 am", color: "bg-blue-400" },
    { label: "AI Extraction Run", time: "10:41:51 am", color: "bg-cyan-400" },
    { label: "Fields Extracted", time: "10:41:52 am", color: "bg-emerald-400" },
    { label: "PDF Generated", time: "10:41:53 am", color: "bg-violet-400" },
    ...(doc.status === "issued" ? [{ label: "AWB Issued", time: "10:41:55 am", color: "bg-blue-400" }] : []),
  ];

  return (
    <>
      <div className="flex h-[60px] shrink-0 items-center gap-2.5 border-b border-white/10 px-[18px]">
        <div className="min-w-0 flex-1">
          <div className="overflow-hidden text-ellipsis whitespace-nowrap font-mono text-xs font-bold text-slate-100">{doc.awb}</div>
          <div className="mt-0.5 text-[10px] text-slate-500">{doc.action} · {doc.date}</div>
        </div>
        <button onClick={onClose} className="flex h-[26px] w-[26px] shrink-0 items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-slate-500 transition hover:border-red-500/30 hover:text-red-400"><Icon name="x" size={11} /></button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 [scrollbar-width:thin]">
        <div className="mb-4 flex flex-wrap items-center gap-2">
          <Badge status={doc.status} />
          <span className="inline-flex items-center rounded border border-blue-500/15 bg-blue-500/10 px-2 py-1 font-mono text-[10px] font-bold text-blue-400">AWB</span>
          <span className="ml-auto text-[11px] text-slate-500">{doc.size} · {doc.pages}p</span>
        </div>

        <section className="mb-[18px]">
          <h3 className="mb-2.5 font-mono text-[9px] uppercase tracking-[0.12em] text-slate-500/80">Extraction Summary</h3>
          <div className="flex overflow-hidden rounded-[10px] border border-white/10">
            <div className="flex-1 border-r border-white/10 p-3 text-center">
              <div className="mb-0.5 font-mono text-lg font-bold text-emerald-400">{doc.extracted}/{doc.fields}</div>
              <div className="text-[9px] tracking-wide text-slate-500">Fields</div>
            </div>
            <div className="flex-1 border-r border-white/10 p-3 text-center">
              <div className="mb-0.5 font-mono text-lg font-bold text-blue-400">{doc.pages}</div>
              <div className="text-[9px] tracking-wide text-slate-500">Pages</div>
            </div>
            <div className="flex-1 p-3 text-center">
              <div className="mb-0.5 font-mono text-lg font-bold text-cyan-400">{doc.extracted === 0 ? "0" : Math.round((doc.extracted / doc.fields) * 100)}%</div>
              <div className="text-[9px] tracking-wide text-slate-500">Accuracy</div>
            </div>
          </div>
        </section>

        <section className="mb-[18px]">
          <h3 className="mb-2.5 font-mono text-[9px] uppercase tracking-[0.12em] text-slate-500/80">Extracted Fields · AI Confidence</h3>
          {fields.slice(0, doc.extracted === 0 ? 2 : fields.length).map((field) => {
            const color = fieldColor(field.confidence);
            return (
              <div key={field.label} className="mb-1.5 rounded-lg border border-white/10 bg-white/[0.03] px-3 py-2.5 transition hover:border-blue-500/20">
                <div className="text-[9px] uppercase tracking-wide text-slate-500">{field.label}</div>
                <div className={`mt-0.5 font-mono text-[11px] font-semibold ${field.confidence === 0 ? "text-red-400" : "text-slate-100"}`}>{field.value}</div>
                {field.confidence > 0 && (
                  <div className="mt-1 flex items-center gap-1.5">
                    <div className="h-0.5 flex-1 overflow-hidden rounded bg-slate-800"><div className={`h-full rounded ${color.split(" ")[0]}`} style={{ width: `${field.confidence}%` }} /></div>
                    <span className={`w-7 text-right font-mono text-[9px] ${color.split(" ")[1]}`}>{field.confidence}%</span>
                  </div>
                )}
              </div>
            );
          })}
        </section>

        <section className="mb-[18px]">
          <h3 className="mb-2.5 font-mono text-[9px] uppercase tracking-[0.12em] text-slate-500/80">Document Timeline</h3>
          {timeline.map((item, index) => (
            <div key={item.label} className="mb-2 flex items-start gap-2.5">
              <div className={`relative mt-1 h-2 w-2 shrink-0 rounded-full ${item.color} ${index !== timeline.length - 1 ? "after:absolute after:left-[3px] after:top-2 after:h-5 after:w-px after:bg-white/10" : ""}`} />
              <div>
                <div className="text-[11px] font-semibold text-slate-300">{item.label}</div>
                <div className="mt-0.5 font-mono text-[9px] text-slate-500">{doc.date} · {item.time}</div>
              </div>
            </div>
          ))}
        </section>
      </div>

      <div className="flex shrink-0 gap-2 border-t border-white/10 px-4 py-3.5">
        <button className="flex flex-1 items-center justify-center gap-1.5 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500 p-2.5 text-xs font-semibold text-white transition hover:-translate-y-0.5 hover:shadow-[0_4px_20px_rgba(59,130,246,0.3)]"><Icon name="open" size={12} />Open Document</button>
        <button className="flex flex-1 items-center justify-center gap-1.5 rounded-lg border border-white/10 bg-transparent p-2.5 text-xs font-semibold text-slate-500 transition hover:border-blue-500/30 hover:text-slate-200"><Icon name="dl" size={12} />Download</button>
      </div>
    </>
  );
}

function StatCard({ label, value, footer, variant }: { label: string; value: number; footer: string; variant: "blue" | "green" | "red" | "amber" }) {
  const variantClasses = {
    blue: "before:from-blue-500 before:to-cyan-500 text-blue-400",
    green: "before:from-emerald-500 before:to-cyan-500 text-emerald-400",
    red: "before:from-red-500 before:to-orange-500 text-red-400",
    amber: "before:from-amber-500 before:to-orange-500 text-amber-400",
  }[variant];

  return (
    <div className={`relative overflow-hidden rounded-xl border border-white/10 bg-white/[0.03] px-[18px] py-4 transition before:absolute before:left-0 before:right-0 before:top-0 before:h-0.5 before:bg-gradient-to-r hover:-translate-y-0.5 hover:border-blue-500/25 hover:shadow-[0_20px_60px_rgba(0,0,0,0.5)] ${variantClasses}`}>
      <div className="mb-2 flex justify-between text-[10px] font-medium uppercase tracking-wide text-slate-500">{label}</div>
      <div className="mb-1.5 font-mono text-[30px] font-bold leading-none tracking-[-0.04em]">{value}</div>
      <div className={`text-[10px] ${variant === "red" ? "cursor-pointer text-blue-400 hover:underline" : "text-slate-500"}`}>{footer}</div>
    </div>
  );
}


export default function HistoryPage() {
  const router = useRouter();
  const [allowed, setAllowed] = useState(false);
  const theme: Theme = "dark";
  const [search, setSearch] = useState("");
  const [dateQuick, setDateQuick] = useState<DateQuick>("all");
  const [fromDate, setFromDate] = useState<Date | null>(null);
  const [toDate, setToDate] = useState<Date | null>(null);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [actionFilter, setActionFilter] = useState("all");
  const [selected, setSelected] = useState<DocRow | null>(null);
  const [page, setPage] = useState(1);
  const [checked, setChecked] = useState<number[]>([]);
  const [sortCol, setSortCol] = useState<SortColumn>("date");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const perPage = 10;

  const filtered = useMemo(() => {
    return docs.filter((doc) => {
      if (search) {
        const query = search.toLowerCase();
        const matched = doc.awb.toLowerCase().includes(query) || doc.action.toLowerCase().includes(query) || doc.user.toLowerCase().includes(query) || doc.date.includes(query);
        if (!matched) return false;
      }
      if (statusFilter !== "all" && doc.status !== statusFilter) return false;
      if (actionFilter !== "all" && doc.action !== actionFilter) return false;
      return true;
    });
  }, [search, statusFilter, actionFilter]);

  const sorted = useMemo(() => {
    return [...filtered].sort((a, b) => {
      const av = String(a[sortCol] ?? "");
      const bv = String(b[sortCol] ?? "");
      return sortDir === "asc" ? av.localeCompare(bv) : bv.localeCompare(av);
    });
  }, [filtered, sortCol, sortDir]);

  const paginated = sorted.slice((page - 1) * perPage, page * perPage);
  const totalPages = Math.max(1, Math.ceil(filtered.length / perPage));

  const stats = {
    total: docs.length,
    success: docs.filter((doc) => ["ok", "issued", "pdf"].includes(doc.status)).length,
    failed: docs.filter((doc) => doc.status === "fail").length,
    draft: docs.filter((doc) => doc.status === "draft").length,
  };

  const toggleCheck = (id: number) => setChecked((current) => (current.includes(id) ? current.filter((item) => item !== id) : [...current, id]));
  const toggleAll = () => setChecked(checked.length === paginated.length ? [] : paginated.map((doc) => doc.id));
  const handleSort = (column: SortColumn) => {
    if (sortCol === column) setSortDir((direction) => (direction === "asc" ? "desc" : "asc"));
    else {
      setSortCol(column);
      setSortDir("asc");
    }
  };

  useEffect(() => {
    const checkSession = () => {
      if (!sessionStorage.getItem("semlox_access_token")) {
        setAllowed(false);
        router.replace("/login");
        return;
      }

      setAllowed(true);
    };

    checkSession();
    window.addEventListener("pageshow", checkSession);

    return () => window.removeEventListener("pageshow", checkSession);
  }, [router]);

  if (!allowed) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#070B17]">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-[#2F80FF]" />
      </main>
    );
  }

  return (
    <main className={`flex h-full flex-col overflow-hidden font-[Inter] ${theme === "dark" ? "bg-[#04060f] text-slate-100" : "bg-slate-100 text-slate-900"}`}>
      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; }
        body { margin: 0; overflow: hidden; }
        @keyframes fadeUp { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
      `}</style>

      {theme === "dark" && (
        <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(59,130,246,0.04)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.04)_1px,transparent_1px)] bg-[length:52px_52px]" />
      )}

      <div className="relative z-10 flex h-full overflow-hidden">
        {/* <aside className="flex w-56 shrink-0 flex-col border-r border-white/10 bg-[#080c1a]">
          <div className="flex h-[60px] shrink-0 items-center gap-2.5 border-b border-white/10 px-[18px]">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-gradient-to-br from-blue-500 to-cyan-500">
              <svg viewBox="0 0 20 20" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" width="18" height="18"><path d="M3 6h9L9 11h8" /></svg>
            </div>
            <div>
              <div className="text-[15px] font-bold tracking-[-0.02em] text-slate-100">Semlo<span className="bg-gradient-to-br from-blue-500 to-cyan-500 bg-clip-text text-transparent">X</span></div>
              <div className="mt-px font-mono text-[9px] uppercase tracking-[0.08em] text-slate-500">AI Document Engine</div>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto py-2.5">
            <div className="px-[18px] pb-1 pt-2 font-mono text-[9px] uppercase tracking-[0.12em] text-slate-500/60">Menu</div>
            {[
              { href: "#", icon: "home" as const, label: "Overview" },
              { href: "#", icon: "doc" as const, label: "AWB Processing", badge: "3" },
              { href: "#", icon: "history" as const, label: "Document Manager", active: true },
              { href: "#", icon: "gear" as const, label: "Settings" },
            ].map((item) => (
              <a key={item.label} href={item.href} className={`relative mx-2 my-px flex items-center gap-2 rounded-lg border px-3 py-2.5 text-[13px] font-medium no-underline transition ${item.active ? "border-blue-500/20 bg-blue-500/10 text-slate-100 before:absolute before:-left-1 before:bottom-1/4 before:top-1/4 before:w-0.5 before:rounded before:bg-gradient-to-b before:from-blue-500 before:to-cyan-500" : "border-transparent text-slate-500 hover:bg-white/[0.055] hover:text-slate-300"}`}>
                <Icon name={item.icon} className={`shrink-0 ${item.active ? "text-blue-400" : "opacity-60"}`} />
                <span className="flex-1">{item.label}</span>
                {item.badge && <span className="rounded-lg bg-blue-500/15 px-1.5 py-0.5 font-mono text-[9px] text-blue-400">{item.badge}</span>}
              </a>
            ))}

            <div className="mx-2.5 my-1.5 h-px bg-white/10" />
            <div className="mx-2 my-1.5 rounded-[10px] border border-blue-500/15 bg-blue-500/[0.06] p-3">
              <div className="mb-0.5 text-[11px] font-semibold text-slate-100">Enterprise Plan</div>
              <div className="mb-2 text-[10px] text-slate-500">10,000 AWBs / month</div>
              <div className="mb-1 h-1 overflow-hidden rounded bg-slate-800"><div className="h-full w-[48%] rounded bg-gradient-to-r from-blue-500 to-cyan-500" /></div>
              <div className="flex justify-between font-mono text-[9px] text-slate-500"><span className="text-blue-400">4,823 used</span><span>5,177 left</span></div>
            </div>
          </div>

          <div className="shrink-0 border-t border-white/10 p-3.5 px-[18px]">
            <div className="flex cursor-pointer items-center gap-2.5 rounded-lg p-1 transition hover:bg-white/[0.055]">
              <div className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-500 text-[11px] font-bold text-white">AK</div>
              <div>
                <div className="text-xs font-semibold text-slate-300">Anna Keller</div>
                <div className="text-[10px] text-slate-500">DB Schenker · Admin</div>
              </div>
              <Icon name="more" className="ml-auto text-slate-500" />
            </div>
          </div>
        </aside> */}

        <section className="flex min-w-0 flex-1 flex-col overflow-hidden">
          {/* <Topbar /> */}
          {/* <header className="flex h-[60px] shrink-0 items-center gap-3 border-b border-white/10 bg-[#080c1a]/85 px-6 backdrop-blur-xl">
            <div>
              <div className="flex items-center gap-1.5 text-xs text-slate-500">
                <a href="#" className="text-slate-500 no-underline transition hover:text-blue-400">Overview</a>
                <Icon name="chevR" size={10} className="text-slate-700" />
                <span className="text-sm font-bold tracking-[-0.02em] text-slate-100">Document Manager</span>
              </div>
              <div className="mt-0.5 text-[11px] text-slate-500">DB Schenker Logistics · 27 Apr 2026</div>
            </div>

            <div className="ml-auto flex items-center gap-2">
              <div className="flex overflow-hidden rounded-lg border border-white/10 bg-white/[0.03] p-0.5">
                <button className={`flex items-center gap-1 rounded-md px-2.5 py-1.5 text-[11px] font-medium transition ${theme === "light" ? "bg-blue-500 text-white" : "text-slate-500"}`} onClick={() => setTheme("light")}><Icon name="sun" size={12} />Light</button>
                <button className={`flex items-center gap-1 rounded-md px-2.5 py-1.5 text-[11px] font-medium transition ${theme === "dark" ? "bg-blue-500 text-white" : "text-slate-500"}`} onClick={() => setTheme("dark")}><Icon name="moon" size={12} />Dark</button>
              </div>
              <button className="flex items-center gap-2 whitespace-nowrap rounded-[9px] bg-gradient-to-br from-blue-500 to-cyan-500 px-[18px] py-2 text-[13px] font-semibold text-white transition hover:-translate-y-0.5 hover:shadow-[0_4px_24px_rgba(59,130,246,0.4)]"><Icon name="upload" size={13} />Upload AWB</button>
              <button className="relative flex h-[34px] w-[34px] items-center justify-center rounded-lg border border-white/10 bg-white/[0.03] text-slate-500 transition hover:border-blue-500/30 hover:text-slate-300"><Icon name="bell" size={14} /><span className="absolute right-[7px] top-1.5 h-1.5 w-1.5 rounded-full border border-[#080c1a] bg-red-500" /></button>
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-500 text-[11px] font-bold text-white">AK</div>
            </div>
          </header> */}

          <div className="flex min-h-0 flex-1 overflow-hidden">
            <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
              <div className="flex flex-1 flex-col gap-4 overflow-y-auto p-5 px-6">
                <div className="flex animate-[fadeUp_0.3s_ease_both] flex-wrap items-start justify-between gap-3">
                  <div>
                    <h1 className="mb-1 text-[22px] font-bold tracking-[-0.03em] text-slate-100">Activity History</h1>
                    <p className="text-xs text-slate-500">Track generated, updated, and finalized AWBs · All document actions</p>
                  </div>
                  <div className="flex flex-wrap items-center gap-2">
                    <div className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-[7px] font-mono text-xs font-bold text-slate-300">Total: {filtered.length}</div>
                    <button className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-[7px] text-xs text-slate-500 transition hover:border-blue-500/30 hover:bg-white/[0.055] hover:text-slate-300"><Icon name="refresh" size={12} />Refresh</button>
                    {checked.length > 0 && <button className="flex items-center gap-1.5 rounded-full border border-blue-500/30 bg-blue-500/10 px-3.5 py-[7px] text-xs text-blue-400"><Icon name="check" size={12} />{checked.length} selected</button>}
                    <button onClick={() => setChecked([])} className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-[7px] text-xs text-slate-500 transition hover:border-red-500/30 hover:text-red-400"><Icon name="x" size={12} />Clear</button>
                    <button className="flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.03] px-3.5 py-[7px] text-xs text-slate-500 transition hover:border-blue-500/30 hover:text-slate-300"><Icon name="dl" size={12} />Export CSV</button>
                  </div>
                </div>

                <div className="grid animate-[fadeUp_0.3s_ease_0.05s_both] grid-cols-1 gap-3 md:grid-cols-2 xl:grid-cols-4">
                  <StatCard label="Total Documents" value={stats.total} footer="All time · all actions" variant="blue" />
                  <StatCard label="Successful" value={stats.success} footer="Issued + PDF + Extracted" variant="green" />
                  <StatCard label="Failed" value={stats.failed} footer="↗ View & re-process" variant="red" />
                  <StatCard label="Draft Saves" value={stats.draft} footer="Pending completion" variant="amber" />
                </div>

                <div className="flex animate-[fadeUp_0.3s_ease_0.08s_both] flex-wrap items-center gap-2 rounded-xl border border-white/10 bg-white/[0.03] px-4 py-3">
                  <div className="flex min-w-[220px] max-w-[280px] flex-1 items-center gap-2 rounded-lg border border-white/10 bg-white/[0.04] px-3 py-[7px] transition focus-within:border-blue-500/40">
                    <Icon name="search" size={13} className="text-slate-500" />
                    <input className="w-full border-none bg-transparent text-xs text-slate-100 outline-none placeholder:text-slate-500" placeholder="Search by AWB #, action, user…" value={search} onChange={(event) => { setSearch(event.target.value); setPage(1); }} />
                  </div>
                  <div className="h-[26px] w-px bg-white/10" />
                  <DateRangePicker from={fromDate} to={toDate} onChange={(from, to) => { setFromDate(from); setToDate(to); }} />
                  <div className="h-[26px] w-px bg-white/10" />
                  <div className="flex flex-wrap gap-2">
                    {(["all", "today", "7d", "30d"] as const).map((key) => (
                      <button key={key} className={`rounded-md border px-3 py-1.5 text-xs transition ${dateQuick === key ? "border-blue-500/35 bg-blue-500/10 font-semibold text-blue-400" : "border-white/10 text-slate-500 hover:border-blue-500/30 hover:text-slate-300"}`} onClick={() => setDateQuick(key)}>{{ all: "All time", today: "Today", "7d": "Last 7 days", "30d": "Last 30 days" }[key]}</button>
                    ))}
                  </div>
                  <div className="h-[26px] w-px bg-white/10" />
                  <select className="rounded-lg border border-white/10 bg-[#0d1323] px-2.5 py-[7px] text-xs text-slate-300 outline-none transition hover:border-blue-500/30" value={statusFilter} onChange={(event) => { setStatusFilter(event.target.value as StatusFilter); setPage(1); }}>
                    <option value="all">All Status</option><option value="ok">Success</option><option value="pdf">PDF Generated</option><option value="issued">AWB Issued</option><option value="partial">Partial</option><option value="draft">Draft</option><option value="fail">Failed</option>
                  </select>
                  <select className="rounded-lg border border-white/10 bg-[#0d1323] px-2.5 py-[7px] text-xs text-slate-300 outline-none transition hover:border-blue-500/30" value={actionFilter} onChange={(event) => { setActionFilter(event.target.value); setPage(1); }}>
                    <option value="all">All Actions</option><option value="Initial Extraction">Initial Extraction</option><option value="Generated PDF">Generated PDF</option><option value="Issued AWB">Issued AWB</option><option value="Draft Saved">Draft Saved</option>
                  </select>
                </div>

                <div className="animate-[fadeUp_0.3s_ease_0.11s_both] overflow-hidden rounded-[14px] border border-white/10 bg-white/[0.03]">
                  <div className="flex flex-wrap items-center gap-2.5 border-b border-white/10 px-[18px] py-3.5">
                    <span className="text-[13px] font-semibold text-slate-100">Documents</span>
                    <span className="rounded bg-blue-500/10 px-2 py-0.5 font-mono text-[11px] text-blue-400">{filtered.length} records</span>
                    {checked.length > 0 && <span className="ml-1 font-mono text-[11px] text-blue-400">{checked.length} selected</span>}
                    <div className="ml-auto flex gap-1.5">
                      {checked.length > 0 ? (
                        <>
                          <button className="rounded-md border border-blue-500/30 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold text-blue-400">Re-process</button>
                          <button className="rounded-md border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold text-slate-500 hover:text-blue-400">Download</button>
                          <button onClick={() => setChecked([])} className="rounded-md border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold text-slate-500 hover:border-red-500/30 hover:text-red-400">Deselect</button>
                        </>
                      ) : (
                        <>
                          <button className="flex items-center gap-1 rounded-md border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold text-slate-500 transition hover:border-blue-500/30 hover:text-blue-400"><Icon name="col" size={11} />Columns</button>
                          <button className="flex items-center gap-1 rounded-md border border-white/10 bg-white/[0.03] px-3 py-1.5 text-[11px] font-semibold text-slate-500 transition hover:border-blue-500/30 hover:text-blue-400"><Icon name="dl" size={11} />Export</button>
                        </>
                      )}
                    </div>
                  </div>

                  <div className="overflow-x-auto">
                    <table className="w-full min-w-[900px] border-collapse">
                      <thead>
                        <tr>
                          <th className="w-9 border-b border-white/10 bg-white/[0.02] py-2.5 pl-4 pr-2 text-left"><CheckboxBox checked={checked.length === paginated.length && paginated.length > 0} onClick={toggleAll} /></th>
                          {tableColumns.map(({ key, label }) => (
                            <th key={key} onClick={() => handleSort(key)} className="cursor-pointer select-none whitespace-nowrap border-b border-white/10 bg-white/[0.02] px-3.5 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-500 transition hover:text-slate-300">
                              {label} <span className="ml-1 text-[9px] opacity-40">{sortCol === key ? (sortDir === "asc" ? "↑" : "↓") : "↕"}</span>
                            </th>
                          ))}
                          <th className="whitespace-nowrap border-b border-white/10 bg-white/[0.02] px-3.5 py-2.5 text-left text-[10px] font-semibold uppercase tracking-[0.08em] text-slate-500">View</th>
                        </tr>
                      </thead>
                      <tbody>
                        {paginated.map((row) => {
                          const isSelected = selected?.id === row.id;
                          const isChecked = checked.includes(row.id);
                          const fieldColor = row.extracted === row.fields ? "bg-emerald-400 text-emerald-400" : row.extracted === 0 ? "bg-red-400 text-red-400" : "bg-amber-400 text-amber-400";
                          return (
                            <tr key={row.id} onClick={() => setSelected(isSelected ? null : row)} className={`cursor-pointer transition ${isSelected ? "bg-blue-500/[0.07]" : "hover:bg-white/[0.025]"}`}>
                              <td className="border-b border-white/[0.03] py-3 pl-4 pr-2" onClick={(event) => { event.stopPropagation(); toggleCheck(row.id); }}><CheckboxBox checked={isChecked} onClick={() => toggleCheck(row.id)} /></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3 text-xs text-slate-300"><div className="whitespace-nowrap font-mono text-[10px] font-semibold text-slate-100">{row.date}</div><div className="mt-px font-mono text-[9px] text-slate-500">{row.time}</div></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3"><span className="font-mono text-[11px] font-bold text-slate-100">{row.awb}</span></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3"><span className={`text-xs font-medium ${actionColor[row.action] ?? "text-slate-300"}`}>{row.action}</span></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3"><span className="inline-flex items-center rounded border border-blue-500/15 bg-blue-500/10 px-2 py-1 font-mono text-[10px] font-bold text-blue-400">{row.type}</span></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3">
                                <div className="flex items-center gap-2">
                                  <span className={`font-mono text-[11px] font-bold ${fieldColor.split(" ")[1]}`}>{row.extracted}/{row.fields}</span>
                                  <div className="h-[3px] w-[52px] overflow-hidden rounded bg-slate-800"><div className={`h-full rounded ${fieldColor.split(" ")[0]}`} style={{ width: `${(row.extracted / row.fields) * 100}%` }} /></div>
                                </div>
                              </td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3">
                                <div className="flex items-center gap-2">
                                  <div className="flex h-[22px] w-[22px] shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-violet-500 text-[8px] font-bold text-white">{row.user.split(" ").map((name) => name[0]).join("")}</div>
                                  <span className="text-xs text-slate-300">{row.user}</span>
                                </div>
                              </td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3"><Badge status={row.status} /></td>
                              <td className="border-b border-white/[0.03] px-3.5 py-3" onClick={(event) => event.stopPropagation()}>
                                <button onClick={() => setSelected(isSelected ? null : row)} className="flex items-center gap-1 rounded-md border border-blue-500/25 bg-blue-500/10 px-3 py-1.5 text-[11px] font-semibold text-blue-400 transition hover:border-blue-500/40 hover:bg-blue-500/20"><Icon name="open" size={11} />Open</button>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>

                  <div className="flex flex-wrap items-center justify-between gap-2 border-t border-white/10 px-[18px] py-3">
                    <div className="font-mono text-[11px] text-slate-500">Showing {filtered.length === 0 ? 0 : (page - 1) * perPage + 1}–{Math.min(page * perPage, filtered.length)} of {filtered.length}</div>
                    <div className="flex gap-1">
                      <button disabled={page === 1} onClick={() => setPage((current) => current - 1)} className="flex h-[30px] w-[30px] items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-xs text-slate-500 transition hover:border-blue-500/30 hover:text-slate-300 disabled:cursor-not-allowed disabled:opacity-30">‹</button>
                      {Array.from({ length: Math.min(totalPages, 5) }, (_, index) => index + 1).map((item) => <button key={item} onClick={() => setPage(item)} className={`flex h-[30px] w-[30px] items-center justify-center rounded-md border text-xs transition ${page === item ? "border-blue-500/35 bg-blue-500/10 font-bold text-blue-400" : "border-white/10 bg-white/[0.03] text-slate-500 hover:border-blue-500/30 hover:text-slate-300"}`}>{item}</button>)}
                      <button disabled={page === totalPages} onClick={() => setPage((current) => current + 1)} className="flex h-[30px] w-[30px] items-center justify-center rounded-md border border-white/10 bg-white/[0.03] text-xs text-slate-500 transition hover:border-blue-500/30 hover:text-slate-300 disabled:cursor-not-allowed disabled:opacity-30">›</button>
                    </div>
                    <div className="flex items-center gap-2 text-[11px] text-slate-500">Rows per page:<select className="rounded-md border border-white/10 bg-white/[0.03] px-2 py-1 text-[11px] text-slate-300 outline-none"><option>10</option><option>25</option><option>50</option></select></div>
                  </div>
                </div>
              </div>
            </div>

            <aside className={`flex shrink-0 flex-col overflow-hidden border-l border-white/10 bg-[#0d1323] transition-[width] duration-300 ${selected ? "w-[380px]" : "w-0"}`}>
              <DetailPanel doc={selected} onClose={() => setSelected(null)} />
            </aside>
          </div>
        </section>
      </div>
    </main>
  );
}
