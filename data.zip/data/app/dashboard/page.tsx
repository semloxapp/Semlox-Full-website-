"use client";

import React, { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  Home,
  FileText,
  Activity,
  Settings,
  MoreHorizontal,
  LogOut,
} from "lucide-react";

import { Upload, Filter, Bell } from "lucide-react";

const colors = {
  accent: "#3B82F6",
  cyan: "#06B6D4",
  green: "#10B981",
  red: "#EF4444",
  amber: "#F59E0B",
  purple: "#8B5CF6",
};

const icons = {
  home: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 6L8 1l6 5v8a1 1 0 01-1 1H3a1 1 0 01-1-1V6z" />
      <path d="M6 15V9h4v6" />
    </svg>
  ),
  doc: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M9 1H3a1 1 0 00-1 1v12a1 1 0 001 1h10a1 1 0 001-1V5L9 1z" />
      <path d="M9 1v4h4M5 9h6M5 12h4" />
    </svg>
  ),
  gear: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="8" cy="8" r="2.5" />
      <path d="M8 1v2M8 13v2M1 8h2M13 8h2M3.05 3.05l1.42 1.42M11.53 11.53l1.42 1.42M3.05 12.95l1.42-1.42M11.53 4.47l1.42-1.42" />
    </svg>
  ),
  bell: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 1a5 5 0 015 5v3l1.5 1.5H.5L2 9V6a5 5 0 015-5z" />
      <path d="M6.5 13a1.5 1.5 0 003 0" />
    </svg>
  ),
  search: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <circle cx="7" cy="7" r="5" />
      <path d="M14 14l-3-3" />
    </svg>
  ),
  cal: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <rect x="1" y="3" width="14" height="12" rx="1" />
      <path d="M1 7h14M5 1v4M11 1v4" />
    </svg>
  ),
  ship: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 10l2-6h8l2 6" />
      <path d="M1 13h14" />
      <path d="M4 10h8" />
      <rect x="6" y="4" width="4" height="3" />
    </svg>
  ),
  check: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2.5 8.5l4 4 7-8" />
    </svg>
  ),
  warn: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M8 1L1 14h14L8 1z" />
      <path d="M8 6v4M8 12v.5" />
    </svg>
  ),
  filter: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round">
      <path d="M2 4h12M5 8h6M7 12h2" />
    </svg>
  ),
  export: (
    <svg viewBox="0 0 16 16" fill="none" stroke="currentColor" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round">
      <path d="M2 12h12M8 2v8M5 6l3-4 3 4" />
    </svg>
  ),
};

function Sparkline({ data, color, height = 32, width = 80 }: { data: number[]; color: string; height?: number; width?: number }) {
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min || 1;
  const pts = data.map((d, i) => [(i / (data.length - 1)) * width, height - ((d - min) / range) * (height - 4)]);
  const line = pts.map((p, i) => `${i === 0 ? "M" : "L"} ${p[0]} ${p[1]}`).join(" ");
  const area = `${line} L ${width} ${height} L 0 ${height} Z`;
  const id = `sg${color.replace("#", "")}`;

  return (
    <svg width={width} height={height} viewBox={`0 0 ${width} ${height}`} className="overflow-visible">
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.2" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} />
      <path d={line} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="2.5" fill={color} />
    </svg>
  );
}

function LineChart({ height = 130 }: { height?: number }) {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  const shipped = [9800, 12100, 11400, 14800, 13200, 10900, 14200];
  const processed = [8200, 10800, 10100, 13400, 11900, 9800, 13100];
  const W = 520;
  const H = height;
  const maxV = 16000;
  const px = (i: number) => 40 + (i / 6) * (W - 60);
  const py = (v: number) => H - 10 - (v / maxV) * (H - 20);

  const makeLine = (data: number[], color: string) => {
    const pts = data.map((v, i) => [px(i), py(v)]);
    const d = pts.map((p, i) => (i === 0 ? `M${p[0]},${p[1]}` : `L${p[0]},${p[1]}`)).join(" ");
    const area = `${d} L${px(6)},${H - 10} L${px(0)},${H - 10} Z`;
    return { d, area, pts, color };
  };

  const lines = [makeLine(shipped, colors.accent), makeLine(processed, colors.cyan)];
  const yTicks = [0, 4000, 8000, 12000, 16000];

  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" style={{ height: H }}>
      <defs>
        <linearGradient id="lga" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colors.accent} stopOpacity="0.12" />
          <stop offset="100%" stopColor={colors.accent} stopOpacity="0" />
        </linearGradient>
        <linearGradient id="lgb" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={colors.cyan} stopOpacity="0.1" />
          <stop offset="100%" stopColor={colors.cyan} stopOpacity="0" />
        </linearGradient>
      </defs>

      {yTicks.map((t) => (
        <g key={t}>
          <line x1="40" y1={py(t)} x2={W - 20} y2={py(t)} stroke="#F3F4F6" strokeWidth="1" />
          <text x="35" y={py(t) + 4} textAnchor="end" fontSize="9" fill="#9CA3AF">
            {t === 0 ? "0" : `${t / 1000}k`}
          </text>
        </g>
      ))}

      {days.map((d, i) => (
        <text key={d} x={px(i)} y={H + 2} textAnchor="middle" fontSize="9" fill="#9CA3AF">
          {d}
        </text>
      ))}

      <path d={lines[0].area} fill="url(#lga)" />
      <path d={lines[1].area} fill="url(#lgb)" />

      {lines.map((line) => (
        <path key={line.color} d={line.d} fill="none" stroke={line.color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      ))}

      {lines[0].pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="2.5" fill={colors.accent} stroke="#fff" strokeWidth="1.5" />
      ))}
      {lines[1].pts.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="2.5" fill={colors.cyan} stroke="#fff" strokeWidth="1.5" />
      ))}

      <line x1={px(4)} y1="10" x2={px(4)} y2={H - 10} stroke="#6B7280" strokeWidth="1" strokeDasharray="3 2" />
    </svg>
  );
}

function DonutChart({ size = 110 }: { size?: number }) {
  const data = [
    { label: "Air Freight", value: 42, color: colors.accent },
    { label: "Ocean", value: 28, color: colors.cyan },
    { label: "Road", value: 20, color: colors.green },
    { label: "Rail", value: 10, color: colors.amber },
  ];
  const total = data.reduce((s, d) => s + d.value, 0);
  const cx = size / 2;
  const cy = size / 2;
  const r = size * 0.38;
  const ri = size * 0.24;
  let angle = -90;

  const arcs = data.map((d) => {
    const start = angle;
    angle += (d.value / total) * 360;
    return { ...d, start, end: angle };
  });

  const arc = (s: number, e: number) => {
    const sr = (s * Math.PI) / 180;
    const er = (e * Math.PI) / 180;
    const x1 = cx + r * Math.cos(sr);
    const y1 = cy + r * Math.sin(sr);
    const x2 = cx + r * Math.cos(er);
    const y2 = cy + r * Math.sin(er);
    const ix1 = cx + ri * Math.cos(sr);
    const iy1 = cy + ri * Math.sin(sr);
    const ix2 = cx + ri * Math.cos(er);
    const iy2 = cy + ri * Math.sin(er);
    const large = e - s > 180 ? 1 : 0;
    return `M${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} L${ix2},${iy2} A${ri},${ri} 0 ${large} 0 ${ix1},${iy1} Z`;
  };

  return (
    <div className="flex items-center gap-5">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {arcs.map((a) => (
          <path key={a.label} d={arc(a.start, a.end)} fill={a.color} />
        ))}
        <circle cx={cx} cy={cy} r={ri - 1} fill="white" />
        <text x={cx} y={cy - 5} textAnchor="middle" fontSize="13" fontWeight="700" fill="#111827">
          42%
        </text>
        <text x={cx} y={cy + 9} textAnchor="middle" fontSize="8" fill="#6B7280">
          Air
        </text>
      </svg>

      <div className="flex flex-col gap-1.5">
        {data.map((d) => (
          <div key={d.label} className="flex items-center gap-2">
            <div className="h-2 w-2 shrink-0 rounded-sm" style={{ background: d.color }} />
            <span className="text-[11px] text-text2">{d.label}</span>
            <span className="ml-auto min-w-7 text-right font-mono text-[11px] font-semibold text-textx">{d.value}%</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function BarChart({ height = 80 }: { height?: number }) {
  const data = [65, 80, 55, 90, 70, 45, 88, 62, 95, 75, 50, 85];
  const labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const max = Math.max(...data);

  return (
    <svg viewBox={`0 0 300 ${height + 20}`} className="w-full" style={{ height: height + 20 }}>
      {data.map((v, i) => {
        const bw = 18;
        const gap = 6;
        const x = i * (bw + gap) + 4;
        const bh = (v / max) * (height - 10);

        return (
          <g key={i}>
            <rect x={x} y={height - bh} width={bw} height={bh} rx="3" fill={i === data.length - 1 ? colors.accent : "#E5E7EB"} />
            {i % 3 === 0 && (
              <text x={x + bw / 2} y={height + 14} textAnchor="middle" fontSize="8" fill="#9CA3AF">
                {labels[i]}
              </text>
            )}
          </g>
        );
      })}
    </svg>
  );
}

function Sidebar({ active = "overview" }: { active?: string }) {
  const navItems = [
    { id: "overview", label: "Overview", icon: icons.home },
    { id: "awb", label: "AWB Processing", icon: icons.doc, badge: "12" },
    { id: "settings", label: "Settings & Integrations", icon: icons.gear },
  ];

  const modules = [
    { label: "Predictive Routing", dot: "#10B981", status: "Live" },
    { label: "Real-time Visibility", dot: "#10B981", status: "Live" },
    { label: "Fleet Intelligence", dot: "#F59E0B", status: "Q3 2026" },
    { label: "Warehouse Vision", dot: "#9CA3AF", status: "Q4 2026" },
  ];

  return (

    <>
      {/* <div className="my-1.5 h-px bg-white/[0.06]" /> */}

    <aside className="flex h-screen w-[220px] shrink-0 flex-col border-r border-white/[0.06] bg-[#070B17] px-2 py-3 text-white">
  {/* Menu */}
  <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
    Menu
  </div>

  <nav className="space-y-1">
    <Link href="/dashboard" className="flex h-[30px] items-center gap-2 rounded-[6px] border border-[#1B3B73] bg-[#0D1B35] px-3 text-[11px] font-bold text-white shadow-[inset_3px_0_0_#2F80FF]">
      <Home className="h-3.5 w-3.5" />
      Overview
    </Link>

    <Link href="/dashboard/awb" className="flex h-[30px] items-center justify-between rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
      <span className="flex items-center gap-2">
        <FileText className="h-3.5 w-3.5" />
        AWB Processing
      </span>
      <span className="flex h-[15px] w-[15px] items-center justify-center rounded-full bg-[#123D8A] text-[8px] font-bold text-[#4F8BFF]">
        3
      </span>
    </Link>

    <Link href="/dashboard/history" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
      <Activity className="h-3.5 w-3.5" />
      History
    </Link>

    <Link href="/dashboard/settings" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
      <Settings className="h-3.5 w-3.5" />
      Settings
    </Link>
  </nav>

  {/* Plan Box */}
  <div className="mt-3 border-t border-white/[0.06] pt-2">
    <div className="rounded-[7px] border border-[#17325F] bg-[#0A1530] p-3">
      <h3 className="text-[10px] font-bold text-white">Enterprise Plan</h3>
      <p className="mt-1 text-[8px] text-[#7D8EA8]">10,000 AWBs/month</p>

      <div className="mt-2 h-[3px] w-full rounded-full bg-[#132746]">
        <div className="h-full w-[48%] rounded-full bg-[#00D9FF]" />
      </div>

      <div className="mt-1.5 flex items-center justify-between text-[8px]">
        <span className="text-[#2F80FF]">4,823</span>
        <span className="text-[#64748B]">of 10,000 used</span>
      </div>
    </div>
  </div>

  {/* Support */}
  <div className="mt-4 border-t border-white/[0.06] pt-3">
    <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
      Support
    </div>

    <a className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
      <FileText className="h-3.5 w-3.5" />
      Documentation
    </a>
  </div>

  <Link href="/logout" className="mt-auto mb-3 flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
    <LogOut className="h-3.5 w-3.5" />
    Logout
  </Link>

  {/* User Profile */}
  <div className="flex items-center justify-between px-3 pb-1">
    <div className="flex items-center gap-2">
      <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#5865F2] text-[9px] font-bold text-white">
        AK
      </div>

      <div className="leading-none">
        <h4 className="text-[10px] font-bold text-white">Anna Keller</h4>
        <p className="mt-1 text-[8px] text-[#64748B]">DB Schenker · Admin</p>
      </div>
    </div>

    <MoreHorizontal className="h-4 w-4 text-[#334155]" />
  </div>
</aside> 
    </>
   
  );
}

function Topbar({ title = "Command Center", sub = "Live Operations Overview — Today, 24 Apr 2026" }: { title?: string; sub?: string }) {
  return (
    <header className="flex h-14 shrink-0 items-center gap-4 border-b border-borderx bg-surface px-6">
      <div>
        <div className="text-base font-bold tracking-[-0.02em] text-textx">{title}</div>
        <div className="mt-px text-[11px] text-muted">{sub}</div>
      </div>

      <div className="ml-auto flex items-center gap-2.5">
        <div className="flex w-[220px] cursor-text items-center gap-2 rounded-lg border border-borderx bg-page px-3.5 py-1.5 text-xs text-muted">
          <span className="flex text-faint">{icons.search}</span>
          <span>Search AWB, route, carrier…</span>
        </div>

        <div className="mx-1 h-5 w-px bg-borderx" />

        <div className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-borderx bg-surface px-3 py-1.5 text-xs text-text2">
          <span className="flex text-muted">{icons.cal}</span>
          Today · 24 Apr 2026
          <span className="text-[10px] text-faint">▾</span>
        </div>

        <div className="icon-btn">{icons.filter}</div>

        <div className="icon-btn">
          {icons.bell}
          <div className="absolute right-1.5 top-[5px] h-1.5 w-1.5 rounded-full border-[1.5px] border-surface bg-redx" />
        </div>

        <div className="h-[30px] w-[30px] shrink-0 rounded-full bg-gradient-to-br from-[#3B82F6] to-[#8B5CF6]" />
      </div>
    </header>
  );
}

void Sidebar;
void Topbar;

function KpiCards() {
  const cards = [
    { label: "Shipments Today", val: "14,208", delta: "+8.2%", dir: "up", vs: "vs yesterday", color: "blue", spark: [90, 110, 95, 130, 115, 105, 142], sparkColor: colors.accent, icon: icons.ship },
    { label: "AWBs Processed", val: "48,231", delta: "+12.4%", dir: "up", vs: "vs yesterday", color: "green", spark: [350, 410, 380, 480, 440, 390, 482], sparkColor: colors.green, icon: icons.doc },
    { label: "On-Time Rate", val: "94.7%", delta: "−1.2%", dir: "down", vs: "vs last week", color: "amber", spark: [96, 97, 95, 98, 94, 96, 95], sparkColor: colors.amber, icon: icons.check },
    { label: "Active Exceptions", val: "23", delta: "+5 new", dir: "down", vs: "since 08:00", color: "red", spark: [8, 12, 10, 18, 14, 19, 23], sparkColor: colors.red, icon: icons.warn },
  ];

  const topBars: Record<string, string> = {
    blue: "from-[#3B82F6] to-[#06B6D4]",
    green: "from-[#10B981] to-[#06B6D4]",
    amber: "from-[#F59E0B] to-[#F97316]",
    red: "from-[#EF4444] to-[#F97316]",
  };

  const iconBg: Record<string, string> = {
    blue: "bg-[#3B82F6]/[0.08]",
    green: "bg-[#10B981]/10",
    amber: "bg-[#F59E0B]/10",
    red: "bg-[#EF4444]/10",
  };

  return (
    <div className="grid grid-cols-4 gap-3.5">
      {cards.map((card) => (
        <div key={card.label} className="relative overflow-hidden rounded-xl border border-borderx bg-surface px-5 py-[18px]">
          <div className={`absolute left-0 right-0 top-0 h-[3px] bg-gradient-to-r ${topBars[card.color]}`} />
          <div className="mb-3 flex items-start justify-between">
            <div className="text-[11px] font-medium uppercase tracking-[0.02em] text-muted">{card.label}</div>
            <div className={`flex h-8 w-8 items-center justify-center rounded-lg ${iconBg[card.color]}`} style={{ color: card.sparkColor }}>
              {card.icon}
            </div>
          </div>
          <div className="mb-2 text-[26px] font-bold leading-none tracking-[-0.03em] text-textx">{card.val}</div>
          <div className="flex items-center gap-2">
            <span className={`flex items-center gap-[3px] text-[11px] font-semibold ${card.dir === "up" ? "text-greenx" : "text-redx"}`}>
              {card.dir === "up" ? "↑" : "↓"} {card.delta}
            </span>
            <span className="text-[11px] text-faint">{card.vs}</span>
            <div className="ml-auto">
              <Sparkline data={card.spark} color={card.sparkColor} width={70} height={28} />
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}

function ShipmentsTable() {
  const rows = [
    { awb: "724-12849302", origin: "FRA", dest: "SIN", carrier: "LH Cargo", status: "transit", statusLabel: "In Transit", progress: 65, eta: "Apr 26", weight: "1,240 kg" },
    { awb: "180-00293817", origin: "JFK", dest: "LHR", carrier: "AA Cargo", status: "customs", statusLabel: "At Customs", progress: 82, eta: "Apr 25", weight: "580 kg" },
    { awb: "618-44192003", origin: "DXB", dest: "BOM", carrier: "EK SkyCargo", status: "delivered", statusLabel: "Delivered", progress: 100, eta: "Done", weight: "3,100 kg" },
    { awb: "020-91843001", origin: "PVG", dest: "LAX", carrier: "CA Cargo", status: "delayed", statusLabel: "Delayed +8h", progress: 38, eta: "Apr 28", weight: "890 kg" },
    { awb: "083-22019847", origin: "AMS", dest: "NBO", carrier: "KL Cargo", status: "transit", statusLabel: "In Transit", progress: 51, eta: "Apr 27", weight: "440 kg" },
    { awb: "724-08839120", origin: "SYD", dest: "CDG", carrier: "QF Freight", status: "processing", statusLabel: "Processing", progress: 12, eta: "May 01", weight: "2,050 kg" },
    { awb: "618-03918201", origin: "ORD", dest: "MAD", carrier: "UA Cargo", status: "processing", statusLabel: "Processing", progress: 64, eta: "Apr 29", weight: "760 kg" },
    { awb: "083-14490021", origin: "GRU", dest: "FRA", carrier: "LA Cargo", status: "customs", statusLabel: "At Customs", progress: 95, eta: "Apr 30", weight: "1,120 kg" },
  ];

  const statusStyles: Record<string, string> = {
    transit: "bg-[#3B82F6]/[0.08] text-accent",
    delivered: "bg-[#10B981]/10 text-greenx",
    delayed: "bg-[#EF4444]/10 text-redx",
    customs: "bg-[#F59E0B]/10 text-amberx",
    processing: "bg-[#8B5CF6]/10 text-purplex",
  };

  const progressColors: Record<string, string> = {
    transit: colors.accent,
    customs: colors.amber,
    delivered: colors.green,
    delayed: colors.red,
    processing: colors.purple,
  };

  return (
    <div className="min-w-0 overflow-hidden rounded-xl border border-borderx bg-surface">
      <div className="flex items-center gap-2.5 border-b border-borderx px-5 pb-3 pt-3.5">
        <span className="text-[13px] font-semibold text-textx">Active Shipments</span>
        <span className="rounded bg-page px-2 py-0.5 font-mono text-[11px] text-muted">1,204 total</span>
        <div className="ml-auto flex gap-2">
          <button className="action-btn flex items-center gap-[5px]">{icons.filter} Filter</button>
          <button className="action-btn flex items-center gap-[5px]">{icons.export} Export</button>
        </div>
      </div>

      <table className="w-full table-fixed border-collapse">
        <colgroup>
          <col className="w-[12%]" />
          <col className="w-[14%]" />
          <col className="w-[13%]" />
          <col className="w-[16%]" />
          <col className="w-[18%]" />
          <col className="w-[8%]" />
          <col className="w-[9%]" />
          <col className="w-[10%]" />
        </colgroup>
        <thead>
          <tr>
            {["AWB Number", "Route", "Carrier", "Status", "Progress", "ETA", "Weight", ""].map((head) => (
              <th key={head} className="border-b border-borderx bg-[#FAFAFA] px-3 py-[9px] text-left text-[10px] font-semibold uppercase tracking-[0.06em] text-faint">
                {head}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row) => (
            <tr key={row.awb} className="hover:bg-[#FAFAFA] [&:last-child_td]:border-b-0">
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle text-xs text-text2">
                <span className="font-mono text-[11px] font-bold text-textx">{row.awb}</span>
              </td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle text-xs text-text2">
                <div className="flex items-center gap-1.5 text-xs">
                  <span className="font-semibold text-textx">{row.origin}</span>
                  <span className="text-[10px] text-faint">→</span>
                  <span className="font-semibold text-textx">{row.dest}</span>
                </div>
              </td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle text-xs text-text2">
                <span className="inline-flex items-center gap-1 rounded border border-borderx bg-page px-2 py-0.5 font-mono text-[10px] text-text2">{row.carrier}</span>
              </td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle text-xs text-text2">
                <span className={`inline-flex items-center gap-[5px] whitespace-nowrap rounded-[20px] px-2.5 py-[3px] text-[10px] font-semibold tracking-[0.03em] ${statusStyles[row.status]}`}>
                  <span className="h-[5px] w-[5px] rounded-full bg-current" />
                  {row.statusLabel}
                </span>
              </td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle text-xs text-text2">
                <div className="flex items-center gap-2">
                  <div className="h-1 min-w-0 flex-1 rounded-sm bg-[#F3F4F6]">
                    <div className="h-full rounded-sm" style={{ width: `${row.progress}%`, background: progressColors[row.status] }} />
                  </div>
                  <span className="w-7 text-right font-mono text-[10px] text-muted">{row.progress}%</span>
                </div>
              </td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle font-mono text-[11px] text-text2">{row.eta}</td>
              <td className="border-b border-[#F3F4F6] px-3 py-3 align-middle font-mono text-[11px] text-muted">{row.weight}</td>
              <td className="border-b border-[#F3F4F6] px-2 py-3 align-middle text-right">
                <button className="action-btn whitespace-nowrap px-2.5">View</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AlertFeed({ className = "" }: { className?: string }) {
  const alerts = [
    { sev: "high", title: "Missing Customs Docs", meta: "AWB 618-44192003 - DXB to BOM", time: "3h ago" },
    { sev: "med", title: "Inspection Scheduled", meta: "AWB 180-00293817 - LHR Customs", time: "4h ago" },
    { sev: "low", title: "Carrier Scan Received", meta: "AWB 724-08839120 - SYD to CDG", time: "5h ago" },
    { sev: "high", title: "Customs Hold — DXB Hub", meta: "AWB 180-00293817 · DXB→BOM", time: "2m ago" },
    { sev: "high", title: "Shipment Delayed +8h", meta: "AWB 020-91843001 · PVG→LAX", time: "11m ago" },
    { sev: "med", title: "Temperature Excursion", meta: "Cold-chain lot #441 · AMS WH", time: "34m ago" },
    { sev: "med", title: "Documentation Incomplete", meta: "AWB 083-22019847 · Origin FRA", time: "1h ago" },
    { sev: "low", title: "Route Updated — ETA Improved", meta: "AWB 724-12849302 · FRA→SIN", time: "2h ago" },
  ];

  const dotStyles: Record<string, string> = {
    high: "bg-redx",
    med: "bg-amberx",
    low: "bg-greenx",
  };

  return (
    <div className={`overflow-hidden rounded-xl border border-borderx bg-surface ${className}`}>
      <div className="flex items-center justify-between border-b border-borderx px-4 py-3">
        <span className="flex items-center gap-2 text-xs font-semibold text-textx">
          <span className="h-[7px] w-[7px] rounded-full bg-redx" />
          Exception Feed
          <span className="rounded-[10px] bg-[#FEE2E2] px-1.5 py-px font-mono text-[10px] font-bold text-redx">23</span>
        </span>
        <span className="cursor-pointer text-[11px] text-accent">View all</span>
      </div>

      {alerts.map((alert, i) => (
        <div key={i} className="alert-feed-row flex gap-3 border-b border-[#F3F4F6] px-4 py-[11px] transition last:border-b-0">
          <div className={`mt-1 h-2 w-2 shrink-0 rounded-full ${dotStyles[alert.sev]}`} />
          <div className="flex-1">
            <div className="mb-0.5 text-xs font-semibold text-textx">{alert.title}</div>
            <div className="flex gap-2 text-[10px] text-muted">{alert.meta}</div>
          </div>
          <div className="ml-auto mt-0.5 whitespace-nowrap font-mono text-[10px] text-faint">{alert.time}</div>
        </div>
      ))}
    </div>
  );
}

// function AwbQueue() {
//   const items = [
//     { num: "724-08839120", route: "SYD→CDG", pct: 12, stage: "OCR Extraction" },
//     { num: "618-03918201", route: "ORD→MAD", pct: 64, stage: "Field Validation" },
//     { num: "020-77710293", route: "ICN→LHR", pct: 88, stage: "Compliance Check" },
//     { num: "083-14490021", route: "GRU→FRA", pct: 95, stage: "Final Review" },
//   ];

//   return (
//     <div className="overflow-hidden rounded-xl border border-borderx bg-surface">
//       <div className="flex items-center justify-between border-b border-borderx px-4 py-3">
//         <span className="flex items-center gap-2 text-xs font-semibold text-textx">📄 AWB Processing Queue</span>
//         <span className="cursor-pointer text-[11px] text-accent">12 pending</span>
//       </div>

//       {items.map((item) => (
//         <div key={item.num} className="flex items-center gap-2.5 border-b border-[#F3F4F6] px-4 py-2.5 hover:bg-[#FAFAFA] last:border-b-0">
//           <div className="flex h-[30px] w-[30px] shrink-0 items-center justify-center rounded-[7px] border border-borderx bg-page text-[13px]">📄</div>
//           <div className="flex-1">
//             <div className="font-mono text-[11px] font-bold text-textx">{item.num}</div>
//             <div className="text-[10px] text-muted">{item.route} · {item.stage}</div>
//           </div>
//           <div className="ml-auto text-right">
//             <div className="font-mono text-[10px] font-bold text-textx">{item.pct}%</div>
//             <div className="mt-[3px] h-[3px] w-[60px] rounded-sm bg-[#F3F4F6]">
//               <div className="h-full rounded-sm bg-gradient-to-r from-accent to-[#06B6D4]" style={{ width: `${item.pct}%` }} />
//             </div>
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// }

// function ModuleStatus() {
//   const modules = [
//     { name: "AWB Automation", status: "Live", dot: "bg-greenx" },
//     { name: "Predictive Routing", status: "Beta", dot: "bg-accent" },
//     { name: "Real-time Visibility", status: "Live", dot: "bg-greenx" },
//     { name: "Fleet Intelligence", status: "Q3 2026", dot: "bg-amberx" },
//     { name: "Warehouse Vision", status: "Q4 2026", dot: "bg-faint" },
//     { name: "Customs AutoFill", status: "Q1 2027", dot: "bg-faint" },
//   ];

//   return (
//     <div className="overflow-hidden rounded-xl border border-borderx bg-surface">
//       <div className="flex items-center justify-between border-b border-borderx px-4 py-3">
//         <span className="flex items-center gap-2 text-xs font-semibold text-textx">⚡ Module Status</span>
//         <span className="cursor-pointer text-[11px] text-accent">Manage</span>
//       </div>

//       <div className="grid grid-cols-2 gap-2 p-3.5">
//         {modules.map((module) => (
//           <div key={module.name} className="flex items-center gap-2.5 rounded-lg border border-borderx bg-[#FAFAFA] px-3 py-2.5">
//             <div className={`h-2 w-2 shrink-0 rounded-full ${module.dot}`} />
//             <div>
//               <div className="text-[11px] font-semibold text-textx">{module.name}</div>
//               <div className="mt-px font-mono text-[9px] uppercase tracking-[0.05em] text-muted">{module.status}</div>
//             </div>
//           </div>
//         ))}
//       </div>
//     </div>
//   );
// }

// function RoadmapPanel() {
//   const items = [
//     { q: "Q3", qcls: "bg-[#3B82F6]/[0.08] text-accent", name: "Fleet Intelligence", desc: "GPS telemetry & predictive maintenance", progress: 35, color: colors.accent },
//     { q: "Q3", qcls: "bg-[#3B82F6]/[0.08] text-accent", name: "Route Optimizer AI", desc: "Dynamic multi-modal path computation", progress: 20, color: colors.cyan },
//     { q: "Q4", qcls: "bg-[#F59E0B]/10 text-amberx", name: "Warehouse Vision", desc: "Computer vision inventory counting", progress: 8, color: colors.amber },
//     { q: "Q4", qcls: "bg-[#F59E0B]/10 text-amberx", name: "Carbon Ledger", desc: "Scope 3 emissions reporting", progress: 5, color: colors.amber },
//     { q: "Q1", qcls: "bg-[#8B5CF6]/10 text-purplex", name: "Customs AutoFill", desc: "AI cross-border documentation", progress: 0, color: colors.purple },
//   ];

//   return (
//     <div className="overflow-hidden rounded-xl border border-borderx bg-surface">
//       <div className="flex items-center justify-between border-b border-borderx px-4 py-3">
//         <span className="flex items-center gap-2 text-xs font-semibold text-textx">🗺️ Upcoming AI Modules</span>
//         <span className="cursor-pointer text-[11px] text-accent">Full roadmap</span>
//       </div>

//       {items.map((item) => (
//         <div key={`${item.q}-${item.name}`} className="flex items-center gap-3 border-b border-[#F3F4F6] px-4 py-2.5 last:border-b-0">
//           <div className={`w-9 shrink-0 rounded-[3px] py-0.5 text-center font-mono text-[9px] font-bold ${item.qcls}`}>{item.q}</div>
//           <div className="flex-1">
//             <div className="text-xs font-semibold text-textx">{item.name}</div>
//             <div className="mt-px text-[10px] text-muted">{item.desc}</div>
//             <div className="mt-[5px] flex items-center gap-2">
//               <div className="h-1 flex-1 overflow-hidden rounded-sm bg-[#F3F4F6]">
//                 <div className="h-full rounded-sm" style={{ width: `${item.progress || 2}%`, background: item.color }} />
//               </div>
//               <span className="w-6 text-right font-mono text-[9px] text-faint">{item.progress}%</span>
//             </div>
//           </div>
//         </div>
//       ))}
//     </div>
//   );
// }

function ChartCard({ children }: { children: React.ReactNode }) {
  return <div className="rounded-xl border border-borderx bg-surface px-5 py-[18px]">{children}</div>;
}

function VariationA() {
  return (
    <main className="flex h-full flex-1 flex-col overflow-hidden bg-page">
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-6 py-5">
          <div className="mb-0.5 flex items-center gap-2.5">
            <span className="font-mono text-[11px] font-semibold tracking-[0.08em] text-muted">VARIATION A — STANDARD GRID</span>
            <span className="rounded bg-[#DBEAFE] px-2 py-0.5 font-mono text-[10px] text-[#1D4ED8]">KPI → Charts → Table + Panels</span>
          </div>

          <KpiCards />

          <div className="grid grid-cols-[2fr_1fr] gap-3.5">
            <ChartCard>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="text-[13px] font-semibold text-textx">Shipment Volume</div>
                  <div className="mt-px text-[11px] text-muted">Shipments dispatched vs AWBs processed · Last 7 days</div>
                </div>
                <div className="flex items-center gap-2">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-[5px] text-[11px] text-muted"><span className="h-2 w-2 rounded-full bg-accent" /> Dispatched</div>
                    <div className="flex items-center gap-[5px] text-[11px] text-muted"><span className="h-2 w-2 rounded-full bg-[#06B6D4]" /> Processed</div>
                  </div>
                  <div className="flex gap-1">
                    {["7D", "30D", "3M"].map((item, i) => (
                      <div key={item} className={`tab-pill ${i === 0 ? "tab-pill-active" : ""}`}>{item}</div>
                    ))}
                  </div>
                </div>
              </div>
              <LineChart height={120} />
            </ChartCard>

            <ChartCard>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="text-[13px] font-semibold text-textx">Modal Split</div>
                  <div className="mt-px text-[11px] text-muted">By freight mode · Today</div>
                </div>
              </div>
              <DonutChart size={110} />
            </ChartCard>
          </div>

          <div className="grid grid-cols-[7fr_3fr] items-stretch gap-3.5">
            <ShipmentsTable />
            <div className="flex min-h-0 flex-col">
              <AlertFeed className="h-full" />
              {/* <AwbQueue /> */}
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3.5">
            {/* <ModuleStatus /> */}
            {/* <RoadmapPanel /> */}
          </div>
        </div>
    </main>
  );
}

function VariationB() {
  return (
    <main className="flex h-full flex-1 flex-col overflow-hidden bg-page">
        <div className="flex flex-1 flex-col gap-4 overflow-y-auto px-6 py-5">
          <div className="mb-0.5 flex items-center gap-2.5">
            <span className="font-mono text-[11px] font-semibold tracking-[0.08em] text-muted">VARIATION B — PRIORITY COMMAND</span>
            <span className="rounded bg-[#FEF3C7] px-2 py-0.5 font-mono text-[10px] text-[#92400E]">Exceptions + Queue prominent · Charts compressed</span>
          </div>

          <KpiCards />

          <div className="grid grid-cols-3 gap-3.5">
            <AlertFeed />
            {/* <AwbQueue /> */}
            <ChartCard>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="text-[13px] font-semibold text-textx">AWB Throughput</div>
                  <div className="mt-px text-[11px] text-muted">Documents processed · Last 12 months</div>
                </div>
              </div>
              <BarChart height={90} />
              <div className="mt-3 flex justify-between border-t border-[#F3F4F6] pt-3">
                {[
                  ["48,231", "Today", "text-textx"],
                  ["98.7%", "Accuracy", "text-greenx"],
                  ["1.9s", "Avg. time", "text-accent"],
                ].map(([value, label, cls]) => (
                  <div key={label} className="text-center">
                    <div className={`font-mono text-base font-bold ${cls}`}>{value}</div>
                    <div className="text-[10px] text-muted">{label}</div>
                  </div>
                ))}
              </div>
            </ChartCard>
          </div>

          <ShipmentsTable />

          <div className="grid grid-cols-[2fr_1fr_1fr] gap-3.5">
            <ChartCard>
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <div className="text-[13px] font-semibold text-textx">Shipment Volume · Last 7 Days</div>
                  <div className="mt-px text-[11px] text-muted">Dispatched vs Processed</div>
                </div>
                <div className="flex items-center gap-3">
                  <div className="flex items-center gap-[5px] text-[11px] text-muted"><span className="h-2 w-2 rounded-full bg-accent" /> Dispatched</div>
                  <div className="flex items-center gap-[5px] text-[11px] text-muted"><span className="h-2 w-2 rounded-full bg-[#06B6D4]" /> Processed</div>
                </div>
              </div>
              <LineChart height={100} />
            </ChartCard>
            {/* <ModuleStatus />
            <RoadmapPanel /> */}
          </div>
        </div>
    </main>
  );
}

export default function Page() {
  const router = useRouter();
  const [allowed, setAllowed] = useState(false);
  const [variation, setVariation] = useState<"A" | "B">("A");

  useEffect(() => {
    const checkSession = () => {
      if (!sessionStorage.getItem("semlox_access_token")) {
        setAllowed(false);
        router.replace("/login");
        return;
      }

      setAllowed(true);
    };

    checkSession();
    window.addEventListener("pageshow", checkSession);

    return () => window.removeEventListener("pageshow", checkSession);
  }, [router]);

  if (!allowed) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#070B17]">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-[#2F80FF]" />
      </main>
    );
  }

  return (
    <div className="flex h-full flex-col">

      <style jsx global>{`
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Mono:wght@400;700&display=swap');
        * { box-sizing: border-box; }
        html, body { margin: 0; min-height: 100%; font-family: 'Inter', sans-serif; background: #EEF1F6; }
        input, button, select { font-family: inherit; }
        .font-mono { font-family: 'Space Mono', monospace; }
        .bg-page { background-color: #EEF1F6; }
        .bg-sidebar { background-color: #111827; }
        .bg-surface { background-color: #FFFFFF; }
        .bg-accent { background-color: #3B82F6; }
        .bg-greenx { background-color: #10B981; }
        .bg-redx { background-color: #EF4444; }
        .bg-amberx { background-color: #F59E0B; }
        .bg-purplex { background-color: #8B5CF6; }
        .bg-faint { background-color: #9CA3AF; }
        .text-textx { color: #111827; }
        .text-text2 { color: #374151; }
        .text-muted { color: #6B7280; }
        .text-faint { color: #9CA3AF; }
        .text-accent { color: #3B82F6; }
        .text-greenx { color: #10B981; }
        .text-redx { color: #EF4444; }
        .text-amberx { color: #F59E0B; }
        .text-purplex { color: #8B5CF6; }
        .border-borderx { border-color: #E5E7EB; }
        .border-surface { border-color: #FFFFFF; }
        .from-accent { --tw-gradient-from: #3B82F6 var(--tw-gradient-from-position); --tw-gradient-to: rgb(59 130 246 / 0) var(--tw-gradient-to-position); --tw-gradient-stops: var(--tw-gradient-from), var(--tw-gradient-to); }
        .frame-tab { cursor: pointer; border-radius: 6px; border: 1px solid rgba(255,255,255,0.12); background: transparent; padding: 5px 16px; font-size: 12px; font-weight: 500; color: #94A3B8; transition: all 0.15s ease; }
        .frame-tab:hover:not(.frame-tab-active) { background: rgba(255,255,255,0.06); color: #fff; }
        .frame-tab-active { background: #3B82F6; border-color: #3B82F6; color: #fff; }
        .nav-item { position: relative; display: flex; cursor: pointer; align-items: center; gap: 10px; border-left: 2px solid transparent; padding: 8px 18px; font-size: 13px; font-weight: 500; color: #9CA3AF; transition: all 0.15s ease; }
        .nav-item:hover { background: rgba(255,255,255,0.04); color: #E5E7EB; }
        .nav-item-active { border-left-color: #3B82F6; background: rgba(59,130,246,0.12); color: #F8FAFC; }
        .icon-btn { position: relative; display: flex; height: 32px; width: 32px; cursor: pointer; align-items: center; justify-content: center; border-radius: 8px; border: 1px solid #E5E7EB; background: transparent; color: #6B7280; }
        .icon-btn svg, .nav-item svg, .action-btn svg { width: 16px; height: 16px; }
        .action-btn { cursor: pointer; border-radius: 6px; border: 1px solid #E5E7EB; background: transparent; padding: 4px 10px; font-size: 10px; font-weight: 500; color: #374151; }
        .tab-pill { cursor: pointer; border-radius: 6px; border: 1px solid #E5E7EB; background: transparent; padding: 4px 10px; font-size: 11px; color: #6B7280; }
        .tab-pill-active { background: #3B82F6; border-color: #3B82F6; color: #fff; }
        .alert-feed-row:hover {
          background-color: #FAFAFA;
        }
        .dashboard-theme-dark .bg-page { background-color: #050813 !important; }
        .dashboard-theme-dark .bg-surface { background-color: #0b1220 !important; }
        .dashboard-theme-dark .border-borderx { border-color: rgba(148, 163, 184, 0.2) !important; }
        .dashboard-theme-dark .text-textx { color: #f8fafc !important; }
        .dashboard-theme-dark .text-text2 { color: #dbeafe !important; }
        .dashboard-theme-dark .text-muted { color: #93a4c3 !important; }
        .dashboard-theme-dark .text-faint { color: #7182a3 !important; }
        .dashboard-theme-dark table th {
          background: #111827 !important;
          color: #93a4c3 !important;
          border-color: rgba(148, 163, 184, 0.2) !important;
        }
        .dashboard-theme-dark table td {
          border-color: rgba(226, 232, 240, 0.65) !important;
        }
        .dashboard-theme-dark tbody tr {
          background: #0b1220 !important;
        }
        .dashboard-theme-dark tbody tr:hover {
          background: #101827 !important;
        }
        .dashboard-theme-dark .alert-feed-row:hover {
          background-color: #101827 !important;
        }
        .dashboard-theme-dark .action-btn,
        .dashboard-theme-dark .tab-pill,
        .dashboard-theme-dark .icon-btn {
          border-color: rgba(203, 213, 225, 0.45) !important;
          color: #cbd5e1 !important;
          background: rgba(15, 23, 42, 0.72) !important;
        }
        .dashboard-theme-dark .action-btn:hover,
        .dashboard-theme-dark .tab-pill:hover,
        .dashboard-theme-dark .icon-btn:hover {
          border-color: rgba(96, 165, 250, 0.6) !important;
          color: #f8fafc !important;
          background: rgba(30, 41, 59, 0.9) !important;
        }
        .dashboard-theme-dark .bg-\\[\\#FAFAFA\\] {
          background-color: #111827 !important;
        }
        .dashboard-theme-dark .hover\\:bg-\\[\\#FAFAFA\\]:hover {
          background-color: #101827 !important;
        }
        .dashboard-theme-dark .border-\\[\\#F3F4F6\\] {
          border-color: rgba(226, 232, 240, 0.65) !important;
        }
      `}</style>


  <div className="hidden">

  {/* LEFT SIDE */}
  <div className="flex items-center gap-4">

    {/* Logo */}
    <div className="flex items-center gap-2">
      <div className="flex h-6 w-6 items-center justify-center rounded-md bg-[#2F80FF]">
        <span className="text-[11px] font-bold text-white">S</span>
      </div>
      <div className="leading-none">
        <h1 className="text-[12px] font-bold">SemloX</h1>
        <p className="text-[8px] text-[#64748B] tracking-[0.1em] mt-1">
          AI DOCUMENT ENGINE
        </p>
      </div>
    </div>

    {/* Divider */}
    <div className="h-10 w-[1px] bg-white/[0.09] ml-12" />

    {/* Page Info */}
    <div className="leading-none ml-3">
      <h2 className="text-[11px] font-semibold text-white mb-0.5">Overview</h2>
      <p className="text-[8px] text-[#64748B]">
        DB Schenker Logistics · Thu, 24 Apr 2026
      </p>
    </div>

  </div>

  {/* RIGHT SIDE */}
  <div className="flex items-center gap-2">

    {/* Upload Button */}
    <button className="flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#2F80FF] to-[#00C6FF] px-3 py-[5px] text-[10px] font-semibold text-white shadow-md hover:opacity-90">
      <Upload className="h-3 w-3" />
      Upload AWB
    </button>

    {/* Icon Buttons */}
    <button className="flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
      <Filter className="h-3.5 w-3.5 text-[#64748B]" />
    </button>

    <button className="relative flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
      <Bell className="h-3.5 w-3.5 text-[#64748B]" />
      <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-red-500" />
    </button>

    {/* Avatar */}
    <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#5865F2] text-[10px] font-bold">
      AK
    </div>

  </div>

</div>

      {variation === "A" ? <VariationA /> : <VariationB />}
    </div>
  );
}
