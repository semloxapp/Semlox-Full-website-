"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import {
  type ChangeEvent,
  type DragEvent,
  type PointerEvent,
  useEffect,
  useRef,
  useState,
} from "react";
import {
  Activity,
  Bell,
  FileText,
  Filter,
  Home,
  LogOut,
  Maximize,
  RotateCw,
  Search,
  Settings,
  Upload,
  ZoomIn,
  ZoomOut,
} from "lucide-react";
import AwbPaperContent from "./components/AwbPaperContent";

type AwbPhase = "upload" | "processing" | "review";

function Sidebar() {
  return (
    <aside className="flex h-screen w-[220px] shrink-0 flex-col border-r border-white/[0.06] bg-[#070B17] px-2 py-3 text-white">
      <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
        Menu
      </div>

      <nav className="space-y-1">
        <Link href="/dashboard" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <Home className="h-3.5 w-3.5" />
          Overview
        </Link>

        <Link href="/dashboard/awb" className="flex h-[30px] items-center justify-between rounded-[6px] border border-[#1B3B73] bg-[#0D1B35] px-3 text-[11px] font-bold text-white shadow-[inset_3px_0_0_#2F80FF]">
          <span className="flex items-center gap-2">
            <FileText className="h-3.5 w-3.5" />
            AWB Processing
          </span>
          <span className="flex h-[15px] w-[15px] items-center justify-center rounded-full bg-[#123D8A] text-[8px] font-bold text-[#4F8BFF]">
            3
          </span>
        </Link>

        <Link href="/dashboard/history" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <Activity className="h-3.5 w-3.5" />
          History
        </Link>

        <Link href="/dashboard/settings" className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <Settings className="h-3.5 w-3.5" />
          Settings
        </Link>
      </nav>

      <div className="mt-3 border-t border-white/[0.06] pt-2">
        <div className="rounded-[7px] border border-[#17325F] bg-[#0A1530] p-3">
          <h3 className="text-[10px] font-bold text-white">Enterprise Plan</h3>
          <p className="mt-1 text-[8px] text-[#7D8EA8]">10,000 AWBs/month</p>
          <div className="mt-2 h-[3px] w-full rounded-full bg-[#132746]">
            <div className="h-full w-[48%] rounded-full bg-[#00D9FF]" />
          </div>
          <div className="mt-1.5 flex items-center justify-between text-[8px]">
            <span className="text-[#2F80FF]">4,823</span>
            <span className="text-[#64748B]">of 10,000 used</span>
          </div>
        </div>
      </div>

      <div className="mt-4 border-t border-white/[0.06] pt-3">
        <div className="mb-2 px-2 text-[8px] font-semibold uppercase tracking-[0.18em] text-[#334155]">
          Support
        </div>

        <a className="flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
          <FileText className="h-3.5 w-3.5" />
          Documentation
        </a>
      </div>

      <Link href="/logout" className="mt-auto mb-3 flex h-[30px] items-center gap-2 rounded-[6px] px-3 text-[11px] font-medium text-[#6F86AA] hover:bg-white/[0.03]">
        <LogOut className="h-3.5 w-3.5" />
        Logout
      </Link>

      <div className="flex items-center justify-between px-3 pb-1">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-full bg-[#5865F2] text-[9px] font-bold text-white">
            AK
          </div>

          <div className="leading-none">
            <h4 className="text-[10px] font-bold text-white">Anna Keller</h4>
            <p className="mt-1 text-[8px] text-[#64748B]">DB Schenker Admin</p>
          </div>
        </div>
      </div>
    </aside>
  );
}

void Sidebar;
void AppHeader;

function AppHeader() {
  return (
    <div className="fixed left-0 right-0 top-0 z-[200] flex h-[42px] items-center justify-between border-b border-white/[0.08] bg-[#070B17] px-5 text-white">
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-2">
          <div className="flex h-6 w-6 items-center justify-center rounded-md bg-[#2F80FF]">
            <span className="text-[11px] font-bold text-white">S</span>
          </div>
          <div className="leading-none">
            <h1 className="text-[12px] font-bold">SemloX</h1>
            <p className="mt-1 text-[8px] tracking-[0.1em] text-[#64748B]">
              AI DOCUMENT ENGINE
            </p>
          </div>
        </div>

        <div className="ml-12 h-10 w-px bg-white/[0.09]" />

        <div className="ml-3 leading-none">
          <h2 className="mb-0.5 text-[11px] font-semibold text-white">AWB Processing</h2>
          <p className="text-[8px] text-[#64748B]">
            DB Schenker Logistics
          </p>
        </div>
      </div>

      <div className="flex items-center gap-2">
        <button className="flex items-center gap-1.5 rounded-md bg-gradient-to-r from-[#2F80FF] to-[#00C6FF] px-3 py-[5px] text-[10px] font-semibold text-white shadow-md hover:opacity-90">
          <Upload className="h-3 w-3" />
          Upload AWB
        </button>

        <button className="flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
          <Filter className="h-3.5 w-3.5 text-[#64748B]" />
        </button>

        <button className="relative flex h-7 w-7 items-center justify-center rounded-md border border-white/[0.08] bg-white/[0.02] hover:bg-white/[0.05]">
          <Bell className="h-3.5 w-3.5 text-[#64748B]" />
          <span className="absolute right-1 top-1 h-1.5 w-1.5 rounded-full bg-red-500" />
        </button>

        <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#5865F2] text-[10px] font-bold">
          AK
        </div>
      </div>
    </div>
  );
}

function ProcessingView({ fileName }: { fileName: string }) {
  return (
    <div className="flex h-full min-h-0 flex-1 items-center justify-center overflow-hidden bg-[radial-gradient(circle_at_35%_35%,rgba(59,130,246,0.08),transparent_32%),linear-gradient(90deg,#20242d_0%,#20242d_42%,#070b17_52%,#050813_100%)] px-5">
      <div className="relative flex h-[200px] w-full max-w-[305px] flex-col items-center justify-center rounded-[10px] border border-white/10 bg-white/[0.035] px-[26px] py-6 text-center shadow-[0_24px_80px_rgba(0,0,0,0.45)] backdrop-blur-md">
        <div className="mb-[18px] h-[46px] w-[46px] animate-spin rounded-full border-2 border-[#334155] border-t-[#2f80ff]" />

        <h2 className="text-[13px] font-extrabold leading-none text-[#f8fafc]">
          Processing {fileName}
        </h2>

        <p className="mt-2 max-w-[210px] text-[9px] leading-[1.25] text-[#64748b]">
          Our AI is extracting all 20 standard fields from your document
        </p>

        <div className="mt-[13px] h-[2px] w-full overflow-hidden bg-[#1e293b]">
          <div className="h-full w-[72%] bg-gradient-to-r from-[#2f80ff] to-[#00d9ff]" />
        </div>

        <div className="mt-2 flex w-full items-center justify-between font-mono text-[8px] text-[#64748b]">
          <span>72% complete</span>
          <span>~1s remaining</span>
        </div>

        <div className="mt-[13px] font-mono text-[9px] text-[#00d9ff]">
          * Cross-checking HS codes...
        </div>
      </div>
    </div>
  );
}

function AwbDocumentPreview({
  fileName,
}: {
  fileName: string;
}) {
  const [page, setPage] = useState(2);
  const [zoom, setZoom] = useState(100);
  const [fitPreview, setFitPreview] = useState(false);
  const [magnifierActive, setMagnifierActive] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [enhanced, setEnhanced] = useState(false);
  const paperRef = useRef<HTMLDivElement | null>(null);
  const [lensPosition, setLensPosition] = useState({
    left: 290,
    top: 110,
    contentX: 250,
    contentY: 90,
  });
  const zoomScale = zoom / 100;

  const moveLens = (event: PointerEvent<HTMLDivElement>) => {
    const container = event.currentTarget;
    const containerRect = container.getBoundingClientRect();
    const paperRect = paperRef.current?.getBoundingClientRect();
    if (!paperRect) return;

    const left = event.clientX - containerRect.left + container.scrollLeft;
    const top = event.clientY - containerRect.top + container.scrollTop;
    const contentX = Math.min(
      paperRect.width,
      Math.max(0, event.clientX - paperRect.left)
    );
    const contentY = Math.min(
      paperRect.height,
      Math.max(0, event.clientY - paperRect.top)
    );

    setLensPosition({
      left,
      top,
      contentX,
      contentY,
    });
  };

  return (
    <div className="awb-document-preview flex h-full min-h-0 flex-col overflow-hidden rounded-[9px] border border-white/[0.08] bg-[#0a0e1a]">
      <div className="awb-preview-toolbar flex h-10 shrink-0 items-center gap-2 border-b border-white/[0.08] bg-[#111726] px-3">
        <FileText className="h-3.5 w-3.5 text-[#ff4d5d]" />
        <span className="max-w-[150px] truncate font-mono text-[10px] font-bold text-white sm:max-w-[190px]">
          {fileName}
        </span>
        <span className="shrink-0 font-mono text-[9px] text-[#64748b]">
          - 312 KB - 2 pages
        </span>
        <div className="ml-auto flex items-center gap-2 font-mono text-[10px] text-white">
          <button onClick={() => setPage((current) => Math.max(1, current - 1))} className="h-6 w-6 rounded border border-white/10 bg-white/[0.04] text-[#64748b] hover:text-white">&lsaquo;</button>
          <span className="rounded border border-white/10 bg-white/[0.05] px-3 py-1">{page}</span>
          <span className="text-[#64748b]">/ 2</span>
          <button onClick={() => setPage((current) => Math.min(2, current + 1))} className="h-6 w-6 rounded border border-white/10 bg-white/[0.04] text-[#64748b] hover:text-white">&rsaquo;</button>
          <button onClick={() => setZoom((current) => Math.max(75, current - 10))} className="ml-3 flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border border-white/10 bg-white/[0.04] text-[#64748b] hover:text-white">
            <ZoomOut className="h-3 w-3" />
          </button>
          <span className="min-w-9 text-center font-extrabold">{zoom}%</span>
          <button onClick={() => setZoom((current) => Math.min(140, current + 10))} className="flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border border-white/10 bg-white/[0.04] text-[#64748b] hover:text-white">
            <ZoomIn className="h-3 w-3" />
          </button>
          <button onClick={() => setFitPreview((current) => !current)} className={`flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border text-[#64748b] hover:text-white ${fitPreview ? "border-[#2f80ff]/50 bg-[#2f80ff]/15" : "border-white/10 bg-white/[0.04]"}`}>
            <Maximize className="h-3 w-3" />
          </button>
          <button onClick={() => setMagnifierActive((current) => !current)} className={`ml-1 flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border ${magnifierActive ? "border-[#2f80ff]/50 bg-[#2f80ff]/15 text-[#60a5fa]" : "border-white/10 bg-white/[0.04] text-[#64748b]"}`}>
            <Search className="h-3 w-3" />
          </button>
          <button onClick={() => setRotation((current) => (current + 90) % 360)} className={`flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border text-[#64748b] hover:text-white ${rotation ? "border-[#2f80ff]/50 bg-[#2f80ff]/15" : "border-white/10 bg-white/[0.04]"}`}>
            <RotateCw className="h-3 w-3" />
          </button>
          <button onClick={() => setEnhanced((current) => !current)} className={`ml-1 flex h-[25px] w-[25px] items-center justify-center rounded-[5px] border text-[#64748b] hover:text-white ${enhanced ? "border-[#2f80ff]/50 bg-[#2f80ff]/15" : "border-white/10 bg-white/[0.04]"}`}>
            <Filter className="h-3 w-3" />
          </button>
        </div>
      </div>

      <div
        onPointerMove={moveLens}
        className={`awb-document-scroll relative min-h-0 flex-1 overflow-y-auto overflow-x-hidden bg-[#1b2232] py-5 ${fitPreview ? "px-8" : "px-12"}`}
      >
        <div
          ref={paperRef}
          className={`mx-auto w-[448px] max-w-full overflow-hidden rounded-[2px] bg-white font-mono text-[#0f172a] shadow-[0_22px_55px_rgba(0,0,0,0.45)] ring-1 ring-black/80 transition-transform duration-200 ${enhanced ? "contrast-125 saturate-125" : ""}`}
          style={{ transform: `scale(${zoomScale}) rotate(${rotation}deg)`, transformOrigin: "top center" }}
        >
          <AwbPaperContent />
        </div>
        {magnifierActive && (
          <div
            className="pointer-events-none absolute z-20 flex h-[145px] w-[145px] -translate-x-1/2 -translate-y-1/2 items-center justify-center overflow-hidden rounded-full border-2 border-[#3b82f6] bg-white text-[#0f172a] shadow-[0_18px_45px_rgba(0,0,0,0.45),inset_0_0_0_1px_rgba(59,130,246,0.18)] [clip-path:circle(50%_at_50%_50%)]"
            style={{ left: `${lensPosition.left}px`, top: `${lensPosition.top}px` }}
          >
            <div className="absolute inset-x-0 top-1/2 h-px bg-[#3b82f6]/60" />
            <div className="absolute inset-y-0 left-1/2 w-px bg-[#3b82f6]/30" />
            <div className="absolute left-1/2 top-1/2 h-3 w-3 -translate-x-1/2 -translate-y-1/2 rounded-full border border-[#3b82f6]/70" />
            <div
              className="absolute w-[500px] bg-white font-mono text-[#0f172a] will-change-transform"
              style={{
                left: `calc(50% - ${lensPosition.contentX * 2}px)`,
                top: `calc(50% - ${lensPosition.contentY * 2}px)`,
                transform: "scale(2)",
                transformOrigin: "top left",
              }}
            >
              <AwbPaperContent />
            </div>
          </div>
        )}
      </div>

      <style jsx global>{`
        .awb-document-scroll {
          scrollbar-width: thin;
          scrollbar-color: #64748b #111827;
        }

        .awb-document-scroll::-webkit-scrollbar {
          width: 9px;
          height: 0;
        }

        .awb-document-scroll::-webkit-scrollbar-track {
          background: #111827;
        }

        .awb-document-scroll::-webkit-scrollbar-thumb {
          background: #64748b;
          border: 2px solid #111827;
          border-radius: 999px;
        }

        .awb-document-scroll textarea,
        .awb-document-scroll input,
        .awb-document-scroll select {
          scrollbar-width: none;
        }

        .awb-document-scroll textarea::-webkit-scrollbar,
        .awb-document-scroll input::-webkit-scrollbar,
        .awb-document-scroll select::-webkit-scrollbar {
          display: none;
        }

        .awb-document-scroll .awb-form input,
        .awb-document-scroll .awb-form textarea,
        .awb-document-scroll .awb-form select {
          background: transparent;
          color: #020617;
          vertical-align: middle;
        }

        .awb-document-scroll .awb-form label,
        .awb-document-scroll .awb-form textarea,
        .awb-document-scroll .awb-form input,
        .awb-document-scroll .awb-form select {
          line-height: 1.15;
        }

        .awb-document-scroll .awb-form * {
          box-sizing: border-box;
        }

        .awb-document-scroll .awb-form input,
        .awb-document-scroll .awb-form textarea {
          min-width: 0;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        .awb-document-scroll .awb-form label,
        .awb-document-scroll .awb-form span,
        .awb-document-scroll .awb-form div {
          overflow-wrap: anywhere;
        }

        .awb-document-scroll .awb-form div:has(> #shipper-name-address),
        .awb-document-scroll .awb-form div:has(> #input-shipper-account-no),
        .awb-document-scroll .awb-form div:has(> #issued-by),
        .awb-document-scroll .awb-form div:has(> #consignee-name-address),
        .awb-document-scroll .awb-form div:has(> #consignee-account-number),
        .awb-document-scroll .awb-form div:has(> #issuing-carrier-agent-iata-code),
        .awb-document-scroll .awb-form div:has(> #departure-airport),
        .awb-document-scroll .awb-form div:has(> #routing-and-destination),
        .awb-document-scroll .awb-form div:has(> #by-first-carrier),
        .awb-document-scroll .awb-form div:has(> #destination-airport),
        .awb-document-scroll .awb-form div:has(> #shipment-referente-number),
        .awb-document-scroll .awb-form div:has(> #shipment-referente-information),
        .awb-document-scroll .awb-form div:has(> #currency),
        .awb-document-scroll .awb-form div:has(> #CHGS),
        .awb-document-scroll .awb-form div:has(> #wt_val_ppd_mark),
        .awb-document-scroll .awb-form div:has(> #wt_val_coll_mark),
        .awb-document-scroll .awb-form div:has(> #pieces),
        .awb-document-scroll .awb-form div:has(> #gross-weight),
        .awb-document-scroll .awb-form div:has(> #weight-unit),
        .awb-document-scroll .awb-form div:has(> #rate-class-code),
        .awb-document-scroll .awb-form div:has(> #rate_class_value),
        .awb-document-scroll .awb-form div:has(> #chargeable-weight),
        .awb-document-scroll .awb-form div:has(> #rate-charge),
        .awb-document-scroll .awb-form div:has(> #total),
        .awb-document-scroll .awb-form div:has(> #nature-and-quantity-of-goods),
        .awb-document-scroll .awb-form div:has(> #pieces_value_total),
        .awb-document-scroll .awb-form div:has(> #gross_weight_total),
        .awb-document-scroll .awb-form div:has(> #total_final_value) {
          background-color: #e4f8f2;
        }

        .awb-document-scroll .awb-form div:has(> #shipper-phone-number),
        .awb-document-scroll .awb-form div:has(> #issuing-carrier-agent-name-and-city),
        .awb-document-scroll .awb-form div:has(> #issuing-carrier-agent-account-no),
        .awb-document-scroll .awb-form div:has(> #value-for-carriage),
        .awb-document-scroll .awb-form div:has(> #other_ppd_mark),
        .awb-document-scroll .awb-form div:has(> #other_coll_mark),
        .awb-document-scroll .awb-form div:has(> #charges-declaration-other) {
          background-color: #fff1dc;
        }

        .awb-document-scroll .awb-form div:has(> #consignee-phone-number),
        .awb-document-scroll .awb-form div:has(> #requested-flight),
        .awb-document-scroll .awb-form div:has(> #requested-date),
        .awb-document-scroll .awb-form div:has(> #value-for-customs),
        .awb-document-scroll .awb-form div:has(> #amount-of-insurance),
        .awb-document-scroll .awb-form div:has(> #handling-information),
        .awb-document-scroll .awb-form div:has(> #special-handling-codes),
        .awb-document-scroll .awb-form div:has(> #other-customs-information),
        .awb-document-scroll .awb-form div:has(> #Weight-charge-collect),
        .awb-document-scroll .awb-form div:has(> #valuation_collect),
        .awb-document-scroll .awb-form div:has(> #tax-collect),
        .awb-document-scroll .awb-form div:has(> #total_other_charges_due_agent_collect),
        .awb-document-scroll .awb-form div:has(> #total_other_charges_due_carrier_collect),
        .awb-document-scroll .awb-form div:has(> #total-collected),
        .awb-document-scroll .awb-form div:has(> #amount-of-insurance) {
          background-color: #ffe4e6;
        }

        .awb-document-scroll .awb-form #shipper-name-address,
        .awb-document-scroll .awb-form #input-shipper-account-no,
        .awb-document-scroll .awb-form #issued-by,
        .awb-document-scroll .awb-form #consignee-name-address,
        .awb-document-scroll .awb-form #consignee-account-number,
        .awb-document-scroll .awb-form #issuing-carrier-agent-iata-code,
        .awb-document-scroll .awb-form #departure-airport,
        .awb-document-scroll .awb-form #routing-and-destination,
        .awb-document-scroll .awb-form #by-first-carrier,
        .awb-document-scroll .awb-form #destination-airport,
        .awb-document-scroll .awb-form #shipment-referente-number,
        .awb-document-scroll .awb-form #shipment-referente-information,
        .awb-document-scroll .awb-form #currency,
        .awb-document-scroll .awb-form #CHGS,
        .awb-document-scroll .awb-form #wt_val_ppd_mark,
        .awb-document-scroll .awb-form #wt_val_coll_mark,
        .awb-document-scroll .awb-form #pieces,
        .awb-document-scroll .awb-form #gross-weight,
        .awb-document-scroll .awb-form #weight-unit,
        .awb-document-scroll .awb-form #rate-class-code,
        .awb-document-scroll .awb-form #rate_class_value,
        .awb-document-scroll .awb-form #chargeable-weight,
        .awb-document-scroll .awb-form #rate-charge,
        .awb-document-scroll .awb-form #total,
        .awb-document-scroll .awb-form #nature-and-quantity-of-goods,
        .awb-document-scroll .awb-form #pieces_value_total,
        .awb-document-scroll .awb-form #gross_weight_total,
        .awb-document-scroll .awb-form #total_final_value {
          background-color: #e4f8f2;
        }

        .awb-document-scroll .awb-form #shipper-phone-number,
        .awb-document-scroll .awb-form #issuing-carrier-agent-name-and-city,
        .awb-document-scroll .awb-form #issuing-carrier-agent-account-no,
        .awb-document-scroll .awb-form #value-for-carriage,
        .awb-document-scroll .awb-form #other_ppd_mark,
        .awb-document-scroll .awb-form #other_coll_mark,
        .awb-document-scroll .awb-form #charges-declaration-other {
          background-color: #fff1dc;
        }

        .awb-document-scroll .awb-form #consignee-phone-number,
        .awb-document-scroll .awb-form #requested-flight,
        .awb-document-scroll .awb-form #requested-date,
        .awb-document-scroll .awb-form #value-for-customs,
        .awb-document-scroll .awb-form #amount-of-insurance,
        .awb-document-scroll .awb-form #handling-information,
        .awb-document-scroll .awb-form #special-handling-codes,
        .awb-document-scroll .awb-form #other-customs-information,
        .awb-document-scroll .awb-form #Weight-charge-collect,
        .awb-document-scroll .awb-form #valuation_collect,
        .awb-document-scroll .awb-form #tax-collect,
        .awb-document-scroll .awb-form #total_other_charges_due_agent_collect,
        .awb-document-scroll .awb-form #total_other_charges_due_carrier_collect,
        .awb-document-scroll .awb-form #total-collected {
          background-color: #ffe4e6;
        }
      `}</style>
    </div>
  );
}

function UploadedPdfPanel({
  fileName,
  pdfUrl,
}: {
  fileName: string;
  pdfUrl: string | null;
}) {
  return (
    <div className="awb-uploaded-pdf-panel flex min-h-0 flex-col overflow-hidden rounded-[9px] border border-white/[0.08] bg-white/[0.03]">
      <div className="flex h-10 shrink-0 items-center border-b border-white/[0.08] px-3">
        <div className="text-[12px] font-extrabold">Uploaded PDF</div>
        <span className="ml-2 min-w-0 truncate font-mono text-[9px] text-[#64748b]">
          {fileName}
        </span>
      </div>

      <div className="min-h-0 flex-1 bg-[#171d2d] p-3">
        {pdfUrl ? (
          <iframe
            src={pdfUrl}
            title={`Uploaded PDF - ${fileName}`}
            className="h-full min-h-[500px] w-full rounded-[6px] border border-white/[0.08] bg-white"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-[12px] text-[#64748b]">
            No PDF selected
          </div>
        )}
      </div>
    </div>
  );
}

function ReviewView({
  fileName,
  pdfUrl,
}: {
  fileName: string;
  pdfUrl: string | null;
}) {
  return (
    <div className="awb-review-page flex h-full min-h-0 flex-col overflow-hidden bg-[#050813] text-white">
      <header className="flex h-[46px] shrink-0 items-center justify-between border-b border-white/[0.08] bg-[#070b17] px-5">
        <div>
          <div className="flex items-center gap-2 text-[11px] font-semibold">
            <span className="text-[#64748b]">Overview</span>
            <span className="text-[#334155]">›</span>
            <span>AWB Processing</span>
          </div>
          <div className="mt-1 text-[9px] text-[#64748b]">
            DB Schenker - Document #724-12849302
          </div>
        </div>

        <div className="flex items-center gap-2">
          <div className="flex rounded-md border border-white/10 bg-white/[0.03] p-0.5 text-[10px]">
            <button className="px-2 py-1 text-[#64748b]">Light</button>
            <button className="rounded bg-[#2f80ff] px-2 py-1 font-bold">Dark</button>
          </div>
          <button className="relative flex h-7 w-7 items-center justify-center rounded-md border border-white/10 bg-white/[0.03]">
            <Bell className="h-3.5 w-3.5 text-[#64748b]" />
            <span className="absolute right-1.5 top-1.5 h-1.5 w-1.5 rounded-full bg-red-500" />
          </button>
          <div className="flex h-7 w-7 items-center justify-center rounded-full bg-[#5865f2] text-[10px] font-bold">
            AK
          </div>
        </div>
      </header>

      <section className="flex min-h-0 flex-1 flex-col gap-3 px-4 py-3">
        <div className="flex shrink-0 items-start justify-between">
          <div>
            <h1 className="text-[18px] font-extrabold tracking-[-0.03em]">AWB Processing</h1>
            <p className="mt-0.5 text-[11px] text-[#64748b]">
              Review extracted fields - 20 of 20 captured - 3 need attention
            </p>
          </div>
          <div className="flex gap-2">
            <button className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-[11px] text-[#64748b]">
              New Document
            </button>
            <button className="rounded-full border border-white/10 bg-white/[0.03] px-4 py-2 text-[11px] text-[#64748b]">
              Save Draft
            </button>
            <button className="rounded-full bg-[#0ea5e9] px-4 py-2 text-[11px] font-bold">
              Issue AWB
            </button>
          </div>
        </div>

        <div className="flex h-[42px] shrink-0 items-center rounded-[9px] border border-white/[0.08] bg-white/[0.025] px-4 text-[11px] font-bold">
          <div className="flex items-center gap-2 text-white">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-[#20c997] text-[10px]">✓</span>
            Upload
          </div>
          <div className="mx-4 h-px flex-1 bg-[#20c997]" />
          <div className="flex items-center gap-2 text-white">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-[#20c997] text-[10px]">✓</span>
            AI Extract
          </div>
          <div className="mx-4 h-px flex-1 bg-[#2f80ff]" />
          <div className="flex items-center gap-2 text-white">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full bg-[#2f80ff] text-[9px] shadow-[0_0_0_4px_rgba(47,128,255,0.18)]">03</span>
            Review Fields
          </div>
          <div className="mx-4 h-px flex-1 bg-white/[0.08]" />
          <div className="flex items-center gap-2 text-[#64748b]">
            <span className="flex h-[18px] w-[18px] items-center justify-center rounded-full border border-white/10 text-[9px]">04</span>
            Issue / Export
          </div>
        </div>

        <div className="flex h-[52px] shrink-0 items-center rounded-[9px] border border-[#00d4aa]/30 bg-[#00d4aa]/[0.07] px-4">
          <div className="mr-3 flex h-8 w-8 items-center justify-center rounded-full bg-[#00d4aa]/20 text-[#00d4aa]">✓</div>
          <div>
            <div className="text-[12px] font-extrabold">Extraction Complete - 20 fields captured in 1.9s</div>
            <div className="mt-0.5 text-[9px] text-[#64748b]">
              3 fields flagged below for review - Verify highlighted entries before issuing
            </div>
          </div>
          <div className="ml-auto grid grid-cols-4 gap-7 text-center font-mono">
            {[["20 / 20", "FIELDS"], ["96%", "AVG CONFIDENCE"], ["5", "REVIEW"], ["1.9s", "PROCESS TIME"]].map(([value, label]) => (
              <div key={label}>
                <div className={`text-[12px] font-extrabold ${label === "REVIEW" ? "text-[#f59e0b]" : "text-[#00d4aa]"}`}>
                  {value}
                </div>
                <div className="mt-1 text-[7px] text-[#64748b]">{label}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="grid min-h-0 flex-1 grid-cols-[1.08fr_0.98fr] gap-3">
          <AwbDocumentPreview fileName={fileName} />

          {/* Extracted fields section hidden by request. Uploaded PDF is shown here instead. */}
          <UploadedPdfPanel fileName={fileName} pdfUrl={pdfUrl} />
          {/* <div className="flex min-h-0 flex-col overflow-hidden rounded-[9px] border border-white/[0.08] bg-white/[0.03]">
            <div className="flex h-10 shrink-0 items-center border-b border-white/[0.08] px-3">
              <div className="text-[12px] font-extrabold">Extracted Fields</div>
              <span className="ml-2 rounded bg-[#00d4aa]/15 px-2 py-1 font-mono text-[9px] text-[#00d4aa]">20/20</span>
              <div className="ml-auto text-[9px] text-[#64748b]">
                Avg. confidence <span className="font-mono font-bold text-[#00d4aa]">96%</span>
              </div>
            </div>

            <div className="flex h-9 shrink-0 items-center gap-6 overflow-hidden border-b border-white/[0.08] px-6 text-[10px] text-[#64748b]">
              {["All 20", "Review 5", "Parties 7", "Route & Flight 6", "Cargo Details 8", "Handling & Charges"].map((tab, index) => (
                <span key={tab} className={index === 0 ? "font-bold text-[#2f80ff]" : ""}>{tab}</span>
              ))}
            </div>

            <div className="h-2 shrink-0 bg-white px-2">
              <div className="mt-[3px] h-1 rounded-full bg-[#7a7f87]" />
            </div>

            <div className="min-h-0 flex-1 space-y-2 overflow-y-auto px-3 py-3">
              <div className="flex justify-between border-b border-dashed border-white/10 pb-2 font-mono text-[9px] uppercase tracking-[0.08em] text-[#64748b]">
                <span>Parties</span>
                <span>7 fields</span>
              </div>
              {fields.map(([label, value, confidence], index) => (
                <ReviewField
                  key={label}
                  label={label}
                  value={value}
                  confidence={confidence}
                  active={index === 1}
                />
              ))}
            </div>

            <div className="flex h-14 shrink-0 items-center border-t border-white/[0.08] px-3">
              <div className="font-mono text-[11px]">
                <span className="font-extrabold text-[#00d4aa]">20/20</span>
                <span className="ml-4 font-extrabold text-[#f59e0b]">5</span>
                <div className="mt-1 text-[8px] text-[#64748b]">Captured To Review</div>
              </div>
              <button className="ml-auto rounded-[8px] bg-[#14b8a6] px-4 py-2 text-[11px] font-extrabold">
                Approve & Issue
              </button>
            </div>
          </div> */}
        </div>
      </section>
      <style jsx global>{`
        .dashboard-theme-light .awb-review-page {
          background-color: #f3f4f6 !important;
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page > header {
          background-color: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page h1,
        .dashboard-theme-light .awb-review-page .awb-preview-toolbar span,
        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel > div:first-child,
        .dashboard-theme-light .awb-review-page section > div:nth-child(3) {
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page p,
        .dashboard-theme-light .awb-review-page header [class*="text-[#64748b]"],
        .dashboard-theme-light .awb-review-page section [class*="text-[#64748b]"] {
          color: #475569 !important;
        }

        .dashboard-theme-light .awb-review-page section > div:nth-child(2) {
          background-color: #f8fafc !important;
          border-color: #cbd5e1 !important;
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page .awb-document-preview,
        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel {
          background-color: #0a0e1a !important;
          border-color: rgba(255, 255, 255, 0.08) !important;
          color: #ffffff !important;
        }

        .dashboard-theme-light .awb-review-page .awb-preview-toolbar,
        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel > div:first-child {
          background-color: #111726 !important;
          border-color: rgba(255, 255, 255, 0.08) !important;
          color: #ffffff !important;
        }

        .dashboard-theme-light .awb-review-page .awb-preview-toolbar span:first-of-type,
        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel > div:first-child > div {
          color: #ffffff !important;
        }

        .dashboard-theme-light .awb-review-page .awb-preview-toolbar span:not(:first-of-type),
        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel > div:first-child > span {
          color: #94a3b8 !important;
        }

        .dashboard-theme-light .awb-review-page .awb-preview-toolbar button {
          background-color: rgba(255, 255, 255, 0.04) !important;
          border-color: rgba(255, 255, 255, 0.1) !important;
          color: #94a3b8 !important;
        }

        .dashboard-theme-light .awb-review-page section > div:first-child button {
          background-color: #ffffff !important;
          border-color: #cbd5e1 !important;
          color: #334155 !important;
        }

        .dashboard-theme-light .awb-review-page section > div:first-child button:last-child {
          background-color: #0ea5e9 !important;
          border-color: #0ea5e9 !important;
          color: #ffffff !important;
        }

        .dashboard-theme-light .awb-review-page section > div:nth-child(2) [class*="text-white"] {
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page section > div:nth-child(3) {
          background-color: #dff8f4 !important;
          border-color: rgba(20, 184, 166, 0.35) !important;
        }

        .dashboard-theme-light .awb-review-page .awb-document-scroll {
          background-color: #1b2232 !important;
        }

        .dashboard-theme-light .awb-review-page .awb-document-scroll .awb-form {
          color: #0f172a !important;
        }

        .dashboard-theme-light .awb-review-page .awb-uploaded-pdf-panel > div:last-child {
          background-color: #171d2d !important;
        }
      `}</style>
    </div>
  );
}


export default function AwbProcessingPage() {
  const router = useRouter();
  const [allowed, setAllowed] = useState(false);
  const [phase, setPhase] = useState<AwbPhase>("upload");
  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);

  const selectedFileName = selectedFile?.name ?? "AWB-724-12849302.pdf";

  const openFilePicker = () => {
    fileInputRef.current?.click();
  };

  const processSelectedFile = (file: File | undefined) => {
    if (!file) return;

    setSelectedFile(file);
    setPdfUrl((currentUrl) => {
      if (currentUrl) URL.revokeObjectURL(currentUrl);
      return URL.createObjectURL(file);
    });
    setPhase("processing");
  };

  const handleFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    processSelectedFile(event.target.files?.[0]);
    event.target.value = "";
  };

  const handleDrop = (event: DragEvent<HTMLDivElement>) => {
    event.preventDefault();
    processSelectedFile(event.dataTransfer.files?.[0]);
  };

  useEffect(() => {
    const checkSession = () => {
      if (!sessionStorage.getItem("semlox_access_token")) {
        setAllowed(false);
        router.replace("/login");
        return;
      }

      setAllowed(true);
    };

    checkSession();
    window.addEventListener("pageshow", checkSession);

    return () => window.removeEventListener("pageshow", checkSession);
  }, [router]);

  useEffect(() => {
    if (phase !== "processing") return;

    const timer = window.setTimeout(() => setPhase("review"), 1800);
    return () => window.clearTimeout(timer);
  }, [phase]);

  useEffect(() => {
    return () => {
      if (pdfUrl) URL.revokeObjectURL(pdfUrl);
    };
  }, [pdfUrl]);

  if (!allowed) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#070B17]">
        <div className="h-8 w-8 animate-spin rounded-full border-2 border-white/20 border-t-[#2F80FF]" />
      </main>
    );
  }

  if (phase === "processing") {
    return <ProcessingView fileName={selectedFileName} />;
  }

  if (phase === "review") {
    return <ReviewView fileName={selectedFileName} pdfUrl={pdfUrl} />;
  }

  return (
    <div className="awb-upload-page h-full overflow-hidden bg-[#04060f]">
               <input
                 ref={fileInputRef}
                 type="file"
                 accept="application/pdf,.pdf"
                 className="hidden"
                 onChange={handleFileChange}
               />
               {/* PAGE CONTENT */}
<div className="flex min-h-0 flex-1 flex-col gap-3.5 overflow-hidden px-5 py-4">

  {/* STEPS */}
  <div className="awb-stepper flex shrink-0 items-center overflow-x-auto rounded-xl border border-white/[0.08] bg-white/[0.03] px-4 py-2.5">

    {/* STEP 1 */}
    <div className="awb-step-active flex shrink-0 items-center gap-2 py-1 text-xs font-semibold text-white">
      <div className="flex h-[22px] w-[22px] items-center justify-center rounded-full border border-[#3b82f6] bg-[#3b82f6] text-[11px] font-bold text-white shadow-[0_0_0_4px_rgba(59,130,246,0.15)]">
        01
      </div>

      <span>Upload</span>
    </div>

    <div className="mx-3 h-px min-w-6 flex-1 bg-white/[0.06]" />

    {/* STEP 2 */}
    <div className="awb-step-muted flex shrink-0 items-center gap-2 py-1 text-xs text-[#64748b]">
      <div className="flex h-[22px] w-[22px] items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.04] text-[11px] font-bold">
        02
      </div>

      <span>AI Extract</span>
    </div>

    <div className="mx-3 h-px min-w-6 flex-1 bg-white/[0.06]" />

    {/* STEP 3 */}
    <div className="awb-step-muted flex shrink-0 items-center gap-2 py-1 text-xs text-[#64748b]">
      <div className="flex h-[22px] w-[22px] items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.04] text-[11px] font-bold">
        03
      </div>

      <span>Review Fields</span>
    </div>

    <div className="mx-3 h-px min-w-6 flex-1 bg-white/[0.06]" />

    {/* STEP 4 */}
    <div className="awb-step-muted flex shrink-0 items-center gap-2 py-1 text-xs text-[#64748b]">
      <div className="flex h-[22px] w-[22px] items-center justify-center rounded-full border border-white/[0.08] bg-white/[0.04] text-[11px] font-bold">
        04
      </div>

      <span>Issue / Export</span>
    </div>
  </div>

  {/* MAIN GRID */}
  <div className="grid min-h-0 flex-1 grid-cols-[minmax(0,1.05fr)_minmax(0,0.95fr)] gap-3.5 overflow-hidden">

    {/* LEFT PANEL */}
    <div className="awb-upload-card flex min-w-0 flex-col overflow-hidden rounded-[14px] border border-white/[0.08] bg-white/[0.03]">

      <div className="flex min-h-0 flex-1 items-center justify-center bg-[#1a1f2e]">

        <div onClick={openFilePicker} onDragOver={(event) => event.preventDefault()} onDrop={handleDrop} className="flex h-[340px] w-4/5 max-w-[520px] cursor-pointer flex-col items-center justify-center gap-3.5 rounded-2xl border-2 border-dashed border-[#3b82f6]/40 bg-[#3b82f6]/[0.05] transition-all duration-200 hover:scale-[1.005] hover:border-[#3b82f6] hover:bg-[#3b82f6]/[0.08]">

          {/* ICON */}
          <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-[#3b82f6]/30 bg-gradient-to-br from-[#3b82f6]/15 to-[#06b6d4]/15 text-[#3b82f6]">
            <svg
  width="28"
  height="28"
  viewBox="0 0 16 16"
  fill="none"
  stroke="currentColor"
  strokeWidth="1.6"
  strokeLinecap="round"
  strokeLinejoin="round"
>
  <path d="M8 1l1.5 4.5L14 7l-4.5 1.5L8 13l-1.5-4.5L2 7l4.5-1.5L8 1z" />
</svg>
          </div>

          {/* TEXT */}
          <div>
            <div className="text-center text-lg font-bold tracking-[-0.02em] text-white">
              Drop AWB here
            </div>

            <div className="mt-1 max-w-[340px] text-center text-[13px] text-[#94a3b8]">
              Drag & drop your PDF, or click to browse. AI will extract
              all 20 standard AWB fields automatically.
            </div>
          </div>

          {/* OR */}
          <div className="flex items-center gap-2 text-[11px] text-[#64748b] before:h-px before:w-[30px] before:bg-white/10 after:h-px after:w-[30px] after:bg-white/10">
            OR
          </div>

          {/* BUTTON */}
          <button onClick={(event) => { event.stopPropagation(); openFilePicker(); }} className="rounded-lg bg-gradient-to-br from-[#3b82f6] to-[#06b6d4] px-[22px] py-[9px] text-xs font-semibold text-white">
            Browse Files
          </button>

          {/* FILE TYPES */}
          <div className="flex flex-wrap justify-center gap-1.5">

            {[".PDF", ".JPG", ".PNG", ".TIFF"].map((item) => (
              <span
                key={item}
                className="rounded border border-white/[0.08] bg-white/[0.05] px-2 py-1 font-mono text-[10px] text-[#94a3b8]"
              >
                {item}
              </span>
            ))}

            <span className="rounded border border-[#3b82f6]/30 bg-white/[0.05] px-2 py-1 font-mono text-[10px] text-[#3b82f6]">
              Max 25 MB
            </span>
          </div>
        </div>
      </div>
    </div>

    {/* RIGHT PANEL */}
    <div className="awb-awaiting-panel flex min-w-0 flex-col overflow-hidden rounded-[14px] border border-white/[0.08] bg-white/[0.03]">

      {/* HEADER */}
      <div className="awb-awaiting-header flex shrink-0 items-center gap-2.5 border-b border-white/[0.06] px-4 py-3">
        <span className="awb-awaiting-title text-[13px] font-semibold text-white">
          Awaiting Document
        </span>
      </div>

      {/* BODY */}
      <div className="flex flex-1 items-center justify-center overflow-y-auto p-10 text-center">

        <div>

          {/* ICON */}
          <div className="mx-auto mb-3.5 flex h-[60px] w-[60px] items-center justify-center rounded-[14px] border border-[#3b82f6]/20 bg-[#3b82f6]/[0.08] text-[#3b82f6]">
            <svg
  width="28"
  height="28"
  viewBox="0 0 16 16"
  fill="none"
  stroke="currentColor"
  strokeWidth="1.6"
  strokeLinecap="round"
  strokeLinejoin="round"
>
  <path d="M8 1l1.5 4.5L14 7l-4.5 1.5L8 13l-1.5-4.5L2 7l4.5-1.5L8 1z" />
</svg>
          </div>

          {/* TITLE */}
          <div className="awb-ready-title mb-1 text-sm font-bold text-white">
            20 fields ready to extract
          </div>

          {/* SUBTITLE */}
          <div className="awb-ready-subtitle mb-[18px] text-[11px] leading-[1.6] text-[#64748b]">
            Once you upload an AWB, our AI will automatically detect and extract:
          </div>

          {/* FIELD GRID */}
          <div className="awb-field-grid grid grid-cols-2 gap-1.5 text-left text-[10px] text-[#cbd5e1]">

            {[
              "AWB Number",
              "Shipper Name",
              "Shipper Account #",
              "Shipper Address",
              "Consignee",
              "Consignee Account #",
              "Consignee Address",
              "Origin Airport",
              "Destination Airport",
              "Flight Number",
              "Flight Date",
              "Issuing Carrier",
            ].map((field) => (
              <div
                key={field}
                className="awb-field-pill flex items-center gap-1.5 rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-1.5"
              >
                <div className="h-[5px] w-[5px] rounded-full bg-[#3b82f6]" />

                {field}
              </div>
            ))}

            <div className="col-span-2 mt-1 text-center text-[10px] text-[#64748b]">
              + 8 more fields
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<style jsx global>{`
  .dashboard-theme-light .awb-upload-page {
    background-color: #f3f4f6 !important;
    color: #0f172a;
  }

  .dashboard-theme-light .awb-upload-page .awb-stepper {
    background-color: #f8fafc !important;
    border-color: #cbd5e1 !important;
    box-shadow: 0 8px 22px rgba(15, 23, 42, 0.04);
  }

  .dashboard-theme-light .awb-upload-page .awb-step-active {
    color: #0f172a !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-step-muted {
    color: #475569 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-stepper > div[class*="h-px"] {
    background-color: #dbe3ef !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card {
    background-color: #f8fafc !important;
    border-color: #cbd5e1 !important;
    box-shadow: 0 8px 22px rgba(15, 23, 42, 0.04);
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card > div {
    background-color: #f8fafc !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card [class*="border-dashed"] {
    background-color: #eff6ff !important;
    border-color: rgba(47, 128, 255, 0.55) !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card [class*="text-white"] {
    color: #0f172a !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card [class*="text-[#94a3b8]"],
  .dashboard-theme-light .awb-upload-page .awb-upload-card [class*="text-[#64748b]"] {
    color: #475569 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-upload-card [class*="bg-white/[0.05]"] {
    background-color: #ffffff !important;
    border-color: #cbd5e1 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-awaiting-panel {
    background-color: #f8fafc !important;
    border-color: #cbd5e1 !important;
    color: #0f172a !important;
    box-shadow: 0 8px 22px rgba(15, 23, 42, 0.04);
  }

  .dashboard-theme-light .awb-upload-page .awb-awaiting-header {
    background-color: #f8fafc !important;
    border-color: #d9e0ea !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-awaiting-title,
  .dashboard-theme-light .awb-upload-page .awb-ready-title {
    color: #0f172a !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-ready-subtitle {
    color: #475569 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-field-grid {
    color: #334155 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-field-pill {
    background-color: #ffffff !important;
    border-color: #cbd5e1 !important;
    color: #334155 !important;
  }

  .dashboard-theme-light .awb-upload-page .awb-field-pill:hover {
    border-color: #93c5fd !important;
    background-color: #eff6ff !important;
  }
`}</style>
    </div>
  );
}
